/* Algebraic */
#include "Sattraj.Satellite_model.h"

#ifdef __cplusplus
extern "C" {
#endif


/* forwarded equations */
extern void Sattraj_Satellite_eqFunction_31(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_32(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_33(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_34(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_35(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_36(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_37(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_38(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_39(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_40(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_41(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_42(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_43(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_44(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_45(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_46(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_47(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_48(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  Sattraj_Satellite_eqFunction_31(data, threadData);

  Sattraj_Satellite_eqFunction_32(data, threadData);

  Sattraj_Satellite_eqFunction_33(data, threadData);

  Sattraj_Satellite_eqFunction_34(data, threadData);

  Sattraj_Satellite_eqFunction_35(data, threadData);

  Sattraj_Satellite_eqFunction_36(data, threadData);

  Sattraj_Satellite_eqFunction_37(data, threadData);

  Sattraj_Satellite_eqFunction_38(data, threadData);

  Sattraj_Satellite_eqFunction_39(data, threadData);

  Sattraj_Satellite_eqFunction_40(data, threadData);

  Sattraj_Satellite_eqFunction_41(data, threadData);

  Sattraj_Satellite_eqFunction_42(data, threadData);

  Sattraj_Satellite_eqFunction_43(data, threadData);

  Sattraj_Satellite_eqFunction_44(data, threadData);

  Sattraj_Satellite_eqFunction_45(data, threadData);

  Sattraj_Satellite_eqFunction_46(data, threadData);

  Sattraj_Satellite_eqFunction_47(data, threadData);

  Sattraj_Satellite_eqFunction_48(data, threadData);
}
/* for continuous time variables */
int Sattraj_Satellite_functionAlgebraics(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  
  data->simulationInfo->callStatistics.functionAlgebraics++;
  
  functionAlg_system0(data, threadData);

  Sattraj_Satellite_function_savePreSynchronous(data, threadData);
  
  TRACE_POP
  return 0;
}

#ifdef __cplusplus
}
#endif
