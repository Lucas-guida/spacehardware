/* Initialization */
#include "Sattraj.Master_model.h"
#include "Sattraj.Master_11mix.h"
#include "Sattraj.Master_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void Sattraj_Master_functionInitialEquations_0(DATA *data, threadData_t *threadData);


/*
 equation index: 1
 type: SIMPLE_ASSIGN
 ARO._long = 0.0174532925199433 * ARO.longitude
 */
void Sattraj_Master_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  data->localData[0]->realVars[20] /* ARO._long variable */ = (0.0174532925199433) * (data->simulationInfo->realParameter[2]);
  TRACE_POP
}

/*
 equation index: 2
 type: SIMPLE_ASSIGN
 ARO._lat = 0.0174532925199433 * ARO.latitude
 */
void Sattraj_Master_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  data->localData[0]->realVars[19] /* ARO._lat variable */ = (0.0174532925199433) * (data->simulationInfo->realParameter[1]);
  TRACE_POP
}

/*
 equation index: 3
 type: SIMPLE_ASSIGN
 ARO._N = DIVISION(6378137.0, sqrt(1.0 + -0.006694379990141317 * sin(ARO.lat) ^ 2.0))
 */
void Sattraj_Master_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = sin(data->localData[0]->realVars[19] /* ARO._lat variable */);
  tmp1 = 1.0 + (-0.006694379990141317) * ((tmp0 * tmp0));
  if(!(tmp1 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(1.0 + -0.006694379990141317 * sin(ARO.lat) ^ 2.0) was %g should be >= 0", tmp1);
  }
  data->localData[0]->realVars[18] /* ARO._N variable */ = DIVISION_SIM(6378137.0,sqrt(tmp1),"sqrt(1.0 + -0.006694379990141317 * sin(ARO.lat) ^ 2.0)",equationIndexes);
  TRACE_POP
}

/*
 equation index: 4
 type: SIMPLE_ASSIGN
 ARO._z = (0.9933056200098587 * ARO.N + ARO.elevation) * sin(ARO.lat)
 */
void Sattraj_Master_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  data->localData[0]->realVars[23] /* ARO._z variable */ = ((0.9933056200098587) * (data->localData[0]->realVars[18] /* ARO._N variable */) + data->simulationInfo->realParameter[0]) * (sin(data->localData[0]->realVars[19] /* ARO._lat variable */));
  TRACE_POP
}

/*
 equation index: 5
 type: SIMPLE_ASSIGN
 ARO._y = (ARO.N + ARO.elevation) * cos(ARO.lat) * sin(ARO.long)
 */
void Sattraj_Master_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  data->localData[0]->realVars[22] /* ARO._y variable */ = (data->localData[0]->realVars[18] /* ARO._N variable */ + data->simulationInfo->realParameter[0]) * ((cos(data->localData[0]->realVars[19] /* ARO._lat variable */)) * (sin(data->localData[0]->realVars[20] /* ARO._long variable */)));
  TRACE_POP
}

/*
 equation index: 6
 type: SIMPLE_ASSIGN
 ARO._x = (ARO.N + ARO.elevation) * cos(ARO.lat) * cos(ARO.long)
 */
void Sattraj_Master_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  data->localData[0]->realVars[21] /* ARO._x variable */ = (data->localData[0]->realVars[18] /* ARO._N variable */ + data->simulationInfo->realParameter[0]) * ((cos(data->localData[0]->realVars[19] /* ARO._lat variable */)) * (cos(data->localData[0]->realVars[20] /* ARO._long variable */)));
  TRACE_POP
}

/*
 equation index: 7
 type: SIMPLE_ASSIGN
 GPS._n = 0.004166666666666667 * GPS.N0 + 9.645061728395061e-008 * GPS.Ndot2 * time + 1.674489883401921e-012 * GPS.Nddot6 * time ^ 2.0
 */
void Sattraj_Master_eqFunction_7(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,7};
  modelica_real tmp2;
  tmp2 = data->localData[0]->timeValue;
  data->localData[0]->realVars[32] /* GPS._n variable */ = (0.004166666666666667) * (data->simulationInfo->realParameter[4]) + (9.645061728395061e-008) * ((data->simulationInfo->realParameter[6]) * (data->localData[0]->timeValue)) + (1.674489883401921e-012) * ((data->simulationInfo->realParameter[5]) * ((tmp2 * tmp2)));
  TRACE_POP
}

/*
 equation index: 8
 type: SIMPLE_ASSIGN
 der(GPS._M) = GPS.n
 */
void Sattraj_Master_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  data->localData[0]->realVars[1] /* der(GPS._M) STATE_DER */ = data->localData[0]->realVars[32] /* GPS._n variable */;
  TRACE_POP
}

/*
 equation index: 9
 type: SIMPLE_ASSIGN
 GPS._a = DIVISION(398600.4418, (-0.0174532925199433 * GPS.n) ^ 2.0) ^ 0.3333333333333333
 */
void Sattraj_Master_eqFunction_9(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,9};
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_real tmp10;
  tmp3 = (-0.0174532925199433) * (data->localData[0]->realVars[32] /* GPS._n variable */);
  tmp4 = DIVISION_SIM(398600.4418,(tmp3 * tmp3),"(-0.0174532925199433 * GPS.n) ^ 2.0",equationIndexes);
  tmp5 = 0.3333333333333333;
  if(tmp4 < 0.0 && tmp5 != 0.0)
  {
    tmp7 = modf(tmp5, &tmp8);
    
    if(tmp7 > 0.5)
    {
      tmp7 -= 1.0;
      tmp8 += 1.0;
    }
    else if(tmp7 < -0.5)
    {
      tmp7 += 1.0;
      tmp8 -= 1.0;
    }
    
    if(fabs(tmp7) < 1e-10)
      tmp6 = pow(tmp4, tmp8);
    else
    {
      tmp10 = modf(1.0/tmp5, &tmp9);
      if(tmp10 > 0.5)
      {
        tmp10 -= 1.0;
        tmp9 += 1.0;
      }
      else if(tmp10 < -0.5)
      {
        tmp10 += 1.0;
        tmp9 -= 1.0;
      }
      if(fabs(tmp10) < 1e-10 && ((unsigned long)tmp9 & 1))
      {
        tmp6 = -pow(-tmp4, tmp7)*pow(tmp4, tmp8);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp4, tmp5);
      }
    }
  }
  else
  {
    tmp6 = pow(tmp4, tmp5);
  }
  if(isnan(tmp6) || isinf(tmp6))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp4, tmp5);
  }
  data->localData[0]->realVars[27] /* GPS._a variable */ = tmp6;
  TRACE_POP
}

/*
 equation index: 10
 type: SIMPLE_ASSIGN
 theta2 = Sattraj.theta_t(din2, tm2)
 */
void Sattraj_Master_eqFunction_10(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,10};
  data->localData[0]->realVars[53] /* theta2 variable */ = omc_Sattraj_theta__t(threadData, data->simulationInfo->realParameter[11], data->simulationInfo->realParameter[15]);
  TRACE_POP
}

/*
 equation index: 11
 type: SIMPLE_ASSIGN
 GPS._M = GPS.M0 + 0.004166666666666667 * GPS.N0 * GPS.tstart + 360.0 * (GPS.Ndot2 * (1.157407407407407e-005 * GPS.tstart) ^ 2.0 + GPS.Nddot6 * (1.157407407407407e-005 * GPS.tstart) ^ 3.0)
 */
void Sattraj_Master_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  modelica_real tmp11;
  modelica_real tmp12;
  tmp11 = (1.157407407407407e-005) * (data->simulationInfo->realParameter[8]);
  tmp12 = (1.157407407407407e-005) * (data->simulationInfo->realParameter[8]);
  data->localData[0]->realVars[0] /* GPS._M STATE(1,GPS.n) */ = data->simulationInfo->realParameter[3] + (0.004166666666666667) * ((data->simulationInfo->realParameter[4]) * (data->simulationInfo->realParameter[8])) + (360.0) * ((data->simulationInfo->realParameter[6]) * ((tmp11 * tmp11)) + (data->simulationInfo->realParameter[5]) * ((tmp12 * tmp12 * tmp12)));
  TRACE_POP
}

void Sattraj_Master_eqFunction_12(DATA*,threadData_t*);
/*
 equation index: 13
 indexNonlinear: 0
 type: NONLINEAR
 
 vars: {GPS._E}
 eqns: {12}
 */
void Sattraj_Master_eqFunction_13(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,13};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 13 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[0].nlsxOld[0] = data->localData[0]->realVars[24] /* GPS._E variable */;
  retValue = solve_nonlinear_system(data, threadData, 0);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,13};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 13 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[24] /* GPS._E variable */ = data->simulationInfo->nonlinearSystemData[0].nlsx[0];
  TRACE_POP
}

/*
 equation index: 14
 type: SIMPLE_ASSIGN
 $TMP$VAR$14$0Y$TAN = DIVISION(tan(0.5 * GPS.E), sqrt(DIVISION(1.0 - GPS.ecc, 1.0 + GPS.ecc)))
 */
void Sattraj_Master_eqFunction_14(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,14};
  modelica_real tmp0;
  tmp0 = DIVISION_SIM(1.0 - data->simulationInfo->realParameter[7],1.0 + data->simulationInfo->realParameter[7],"1.0 + GPS.ecc",equationIndexes);
  if(!(tmp0 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(DIVISION(1.0 - GPS.ecc, 1.0 + GPS.ecc)) was %g should be >= 0", tmp0);
  }
  data->localData[0]->realVars[4] /* $TMP$VAR$14$0Y$TAN variable */ = DIVISION_SIM(tan((0.5) * (data->localData[0]->realVars[24] /* GPS._E variable */)),sqrt(tmp0),"sqrt(DIVISION(1.0 - GPS.ecc, 1.0 + GPS.ecc))",equationIndexes);
  TRACE_POP
}

/*
 equation index: 15
 type: SIMPLE_ASSIGN
 $TMP$VAR$14$0ATAN$TAN = atan($TMP$VAR$14$0Y$TAN)
 */
void Sattraj_Master_eqFunction_15(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,15};
  data->localData[0]->realVars[2] /* $TMP$VAR$14$0ATAN$TAN variable */ = atan(data->localData[0]->realVars[4] /* $TMP$VAR$14$0Y$TAN variable */);
  TRACE_POP
}

/*
 equation index: 16
 type: SIMPLE_ASSIGN
 $TMP$VAR$14$0PREX$TAN = if initial() then if pre(GPS.theta) == 0.0 then 1.0 else 0.5 * pre(GPS.theta) else 0.5 * pre(GPS.theta)
 */
void Sattraj_Master_eqFunction_16(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,16};
  data->localData[0]->realVars[3] /* $TMP$VAR$14$0PREX$TAN variable */ = (initial()?((data->simulationInfo->realVarsPre[36] /* GPS._theta variable */ == 0.0)?1.0:(0.5) * (data->simulationInfo->realVarsPre[36] /* GPS._theta variable */)):(0.5) * (data->simulationInfo->realVarsPre[36] /* GPS._theta variable */));
  TRACE_POP
}

/*
 equation index: 17
 type: SIMPLE_ASSIGN
 GPS._theta = 2.0 * $TMP$VAR$14$0ATAN$TAN + 6.283185307179586 * $_round(($TMP$VAR$14$0PREX$TAN - $TMP$VAR$14$0ATAN$TAN) / 3.141592653589793)
 */
void Sattraj_Master_eqFunction_17(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,17};
  modelica_real tmp2;
  tmp2 = 3.141592653589793;
  if (tmp2 == 0) {throwStreamPrint(threadData, "Division by zero %s", "($TMP$VAR$14$0PREX$TAN - $TMP$VAR$14$0ATAN$TAN) / 3.141592653589793");}
  data->localData[0]->realVars[36] /* GPS._theta variable */ = (2.0) * (data->localData[0]->realVars[2] /* $TMP$VAR$14$0ATAN$TAN variable */) + (6.283185307179586) * (((modelica_integer)round((modelica_real)((data->localData[0]->realVars[3] /* $TMP$VAR$14$0PREX$TAN variable */ - data->localData[0]->realVars[2] /* $TMP$VAR$14$0ATAN$TAN variable */) / tmp2))));
  TRACE_POP
}

/*
 equation index: 18
 type: SIMPLE_ASSIGN
 GPS._r = GPS.a * DIVISION(1.0 - GPS.ecc ^ 2.0, 1.0 + GPS.ecc * cos(GPS.theta))
 */
void Sattraj_Master_eqFunction_18(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,18};
  modelica_real tmp3;
  tmp3 = data->simulationInfo->realParameter[7];
  data->localData[0]->realVars[35] /* GPS._r variable */ = (data->localData[0]->realVars[27] /* GPS._a variable */) * (DIVISION_SIM(1.0 - ((tmp3 * tmp3)),1.0 + (data->simulationInfo->realParameter[7]) * (cos(data->localData[0]->realVars[36] /* GPS._theta variable */)),"1.0 + GPS.ecc * cos(GPS.theta)",equationIndexes));
  TRACE_POP
}

/*
 equation index: 19
 type: SIMPLE_ASSIGN
 GPS._x = GPS.r * cos(GPS.theta)
 */
void Sattraj_Master_eqFunction_19(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,19};
  data->localData[0]->realVars[38] /* GPS._x variable */ = (data->localData[0]->realVars[35] /* GPS._r variable */) * (cos(data->localData[0]->realVars[36] /* GPS._theta variable */));
  TRACE_POP
}

/*
 equation index: 20
 type: SIMPLE_ASSIGN
 GPS._y = GPS.r * sin(GPS.theta)
 */
void Sattraj_Master_eqFunction_20(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,20};
  data->localData[0]->realVars[39] /* GPS._y variable */ = (data->localData[0]->realVars[35] /* GPS._r variable */) * (sin(data->localData[0]->realVars[36] /* GPS._theta variable */));
  TRACE_POP
}

/*
 equation index: 21
 type: SIMPLE_ASSIGN
 $TMP$VAR$21$0X$ABS = pre(GPS.h)
 */
void Sattraj_Master_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  data->localData[0]->realVars[5] /* $TMP$VAR$21$0X$ABS variable */ = data->simulationInfo->realVarsPre[31] /* GPS._h variable */;
  TRACE_POP
}

/*
 equation index: 22
 type: SIMPLE_ASSIGN
 GPS._h = $_signNoNull($TMP$VAR$21$0X$ABS) * abs(-398600.4418 ^ 0.5 * (-GPS.r) ^ 0.5 * (1.0 + GPS.ecc * cos(GPS.theta)) ^ 0.5)
 */
void Sattraj_Master_eqFunction_22(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,22};
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  tmp4 = -398600.4418;
  if(!(tmp4 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-398600.4418) was %g should be >= 0", tmp4);
  }tmp5 = (-data->localData[0]->realVars[35] /* GPS._r variable */);
  if(!(tmp5 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-GPS.r) was %g should be >= 0", tmp5);
  }tmp6 = 1.0 + (data->simulationInfo->realParameter[7]) * (cos(data->localData[0]->realVars[36] /* GPS._theta variable */));
  if(!(tmp6 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(1.0 + GPS.ecc * cos(GPS.theta)) was %g should be >= 0", tmp6);
  }
  data->localData[0]->realVars[31] /* GPS._h variable */ = ((data->localData[0]->realVars[5] /* $TMP$VAR$21$0X$ABS variable */ >= 0.0 ? 1.0:-1.0)) * (fabs((sqrt(tmp4)) * ((sqrt(tmp5)) * (sqrt(tmp6)))));
  TRACE_POP
}

/*
 equation index: 23
 type: SIMPLE_ASSIGN
 GPS._dr = 398600.4418 * GPS.ecc * DIVISION(sin(GPS.theta), GPS.h)
 */
void Sattraj_Master_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,23};
  data->localData[0]->realVars[28] /* GPS._dr variable */ = (398600.4418) * ((data->simulationInfo->realParameter[7]) * (DIVISION_SIM(sin(data->localData[0]->realVars[36] /* GPS._theta variable */),data->localData[0]->realVars[31] /* GPS._h variable */,"GPS.h",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 24
 type: SIMPLE_ASSIGN
 GPS._dx = -398600.4418 * DIVISION(sin(GPS.theta), GPS.h)
 */
void Sattraj_Master_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,24};
  data->localData[0]->realVars[29] /* GPS._dx variable */ = (-398600.4418) * (DIVISION_SIM(sin(data->localData[0]->realVars[36] /* GPS._theta variable */),data->localData[0]->realVars[31] /* GPS._h variable */,"GPS.h",equationIndexes));
  TRACE_POP
}

/*
 equation index: 25
 type: SIMPLE_ASSIGN
 GPS._dy = 398600.4418 * DIVISION(GPS.ecc + cos(GPS.theta), GPS.h)
 */
void Sattraj_Master_eqFunction_25(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,25};
  data->localData[0]->realVars[30] /* GPS._dy variable */ = (398600.4418) * (DIVISION_SIM(data->simulationInfo->realParameter[7] + cos(data->localData[0]->realVars[36] /* GPS._theta variable */),data->localData[0]->realVars[31] /* GPS._h variable */,"GPS.h",equationIndexes));
  TRACE_POP
}

/*
 equation index: 26
 type: ALGORITHM
 
   (p, v) := Sattraj.sat_ECI(Sattraj.Vector(GPS.x, GPS.y, 0.0), Sattraj.Vector(GPS.dx, GPS.dy, 0.0), GPS.ecc, raan2, inc2, argper2, GPS.N0);
 */
void Sattraj_Master_eqFunction_26(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,26};
  Sattraj_Vector tmp7;
  Sattraj_Vector tmp8;
  tmp8 = omc_Sattraj_sat__ECI(threadData, omc_Sattraj_Vector(threadData, data->localData[0]->realVars[38] /* GPS._x variable */, data->localData[0]->realVars[39] /* GPS._y variable */, 0.0), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[29] /* GPS._dx variable */, data->localData[0]->realVars[30] /* GPS._dy variable */, 0.0), data->simulationInfo->realParameter[7], data->simulationInfo->realParameter[14], data->simulationInfo->realParameter[13], data->simulationInfo->realParameter[9], data->simulationInfo->realParameter[4] ,&tmp7);
  data->localData[0]->realVars[44] /* p._x variable */ = tmp8._x;
  data->localData[0]->realVars[45] /* p._y variable */ = tmp8._y;
  data->localData[0]->realVars[46] /* p._z variable */ = tmp8._z;
  data->localData[0]->realVars[54] /* v._x variable */ = tmp7._x;
  data->localData[0]->realVars[55] /* v._y variable */ = tmp7._y;
  data->localData[0]->realVars[56] /* v._z variable */ = tmp7._z;
  TRACE_POP
}

/*
 equation index: 27
 type: ALGORITHM
 
   (p2, v2) := Sattraj.sat_ECF(p, v, theta2);
 */
void Sattraj_Master_eqFunction_27(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,27};
  Sattraj_Vector tmp9;
  Sattraj_Vector tmp10;
  tmp10 = omc_Sattraj_sat__ECF(threadData, omc_Sattraj_Vector(threadData, data->localData[0]->realVars[44] /* p._x variable */, data->localData[0]->realVars[45] /* p._y variable */, data->localData[0]->realVars[46] /* p._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[54] /* v._x variable */, data->localData[0]->realVars[55] /* v._y variable */, data->localData[0]->realVars[56] /* v._z variable */), data->localData[0]->realVars[53] /* theta2 variable */ ,&tmp9);
  data->localData[0]->realVars[47] /* p2._x variable */ = tmp10._x;
  data->localData[0]->realVars[48] /* p2._y variable */ = tmp10._y;
  data->localData[0]->realVars[49] /* p2._z variable */ = tmp10._z;
  data->localData[0]->realVars[57] /* v2._x variable */ = tmp9._x;
  data->localData[0]->realVars[58] /* v2._y variable */ = tmp9._y;
  data->localData[0]->realVars[59] /* v2._z variable */ = tmp9._z;
  TRACE_POP
}

/*
 equation index: 28
 type: ALGORITHM
 
   (p3, v3) := Sattraj.range_ECF2topo(p2, v2, Sattraj.Vector(ARO.x, ARO.y, ARO.z), ARO.longitude, ARO.latitude);
 */
void Sattraj_Master_eqFunction_28(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,28};
  Sattraj_Vector tmp11;
  Sattraj_Vector tmp12;
  tmp12 = omc_Sattraj_range__ECF2topo(threadData, omc_Sattraj_Vector(threadData, data->localData[0]->realVars[47] /* p2._x variable */, data->localData[0]->realVars[48] /* p2._y variable */, data->localData[0]->realVars[49] /* p2._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[57] /* v2._x variable */, data->localData[0]->realVars[58] /* v2._y variable */, data->localData[0]->realVars[59] /* v2._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[21] /* ARO._x variable */, data->localData[0]->realVars[22] /* ARO._y variable */, data->localData[0]->realVars[23] /* ARO._z variable */), data->simulationInfo->realParameter[2], data->simulationInfo->realParameter[1] ,&tmp11);
  data->localData[0]->realVars[50] /* p3._x variable */ = tmp12._x;
  data->localData[0]->realVars[51] /* p3._y variable */ = tmp12._y;
  data->localData[0]->realVars[52] /* p3._z variable */ = tmp12._z;
  data->localData[0]->realVars[60] /* v3._x variable */ = tmp11._x;
  data->localData[0]->realVars[61] /* v3._y variable */ = tmp11._y;
  data->localData[0]->realVars[62] /* v3._z variable */ = tmp11._z;
  TRACE_POP
}

/*
 equation index: 29
 type: ALGORITHM
 
   (azimuth2, elevation2, dAz2, dEl2) := Sattraj.range_topo2look_angles(az_vel_lim2, el_vel_lim2, p, v);
 */
void Sattraj_Master_eqFunction_29(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,29};
  data->localData[0]->realVars[40] /* azimuth2 variable */ = omc_Sattraj_range__topo2look__angles(threadData, data->simulationInfo->realParameter[10], data->simulationInfo->realParameter[12], omc_Sattraj_Vector(threadData, data->localData[0]->realVars[44] /* p._x variable */, data->localData[0]->realVars[45] /* p._y variable */, data->localData[0]->realVars[46] /* p._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[54] /* v._x variable */, data->localData[0]->realVars[55] /* v._y variable */, data->localData[0]->realVars[56] /* v._z variable */) ,&data->localData[0]->realVars[43] /* elevation2 variable */ ,&data->localData[0]->realVars[41] /* dAz2 variable */ ,&data->localData[0]->realVars[42] /* dEl2 variable */);
  TRACE_POP
}

/*
 equation index: 30
 type: SIMPLE_ASSIGN
 GPS._Mean = mod(GPS.M, 360.0)
 */
void Sattraj_Master_eqFunction_30(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,30};
  modelica_real tmp13;
  tmp13 = 360.0;
  if (tmp13 == 0) {throwStreamPrint(threadData, "Division by zero %s", "mod(GPS.M, 360.0)");}
  data->localData[0]->realVars[26] /* GPS._Mean variable */ = ((data->localData[0]->realVars[0] /* GPS._M STATE(1,GPS.n) */) - floor((data->localData[0]->realVars[0] /* GPS._M STATE(1,GPS.n) */) / (tmp13)) * (tmp13));
  TRACE_POP
}

/*
 equation index: 31
 type: SIMPLE_ASSIGN
 GPS._v_sat_p._z = 0.0
 */
void Sattraj_Master_eqFunction_31(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,31};
  data->localData[0]->realVars[37] /* GPS._v_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 32
 type: SIMPLE_ASSIGN
 GPS._p_sat_p._z = 0.0
 */
void Sattraj_Master_eqFunction_32(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,32};
  data->localData[0]->realVars[33] /* GPS._p_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 33
 type: SIMPLE_ASSIGN
 GPS._GM = 398600.4418
 */
void Sattraj_Master_eqFunction_33(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,33};
  data->localData[0]->realVars[25] /* GPS._GM variable */ = 398600.4418;
  TRACE_POP
}

/*
 equation index: 34
 type: SIMPLE_ASSIGN
 GPS._pi = 3.141592653589793
 */
void Sattraj_Master_eqFunction_34(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,34};
  data->localData[0]->realVars[34] /* GPS._pi variable */ = 3.141592653589793;
  TRACE_POP
}
void Sattraj_Master_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Sattraj_Master_eqFunction_1(data, threadData);
  Sattraj_Master_eqFunction_2(data, threadData);
  Sattraj_Master_eqFunction_3(data, threadData);
  Sattraj_Master_eqFunction_4(data, threadData);
  Sattraj_Master_eqFunction_5(data, threadData);
  Sattraj_Master_eqFunction_6(data, threadData);
  Sattraj_Master_eqFunction_7(data, threadData);
  Sattraj_Master_eqFunction_8(data, threadData);
  Sattraj_Master_eqFunction_9(data, threadData);
  Sattraj_Master_eqFunction_10(data, threadData);
  Sattraj_Master_eqFunction_11(data, threadData);
  Sattraj_Master_eqFunction_13(data, threadData);
  Sattraj_Master_eqFunction_14(data, threadData);
  Sattraj_Master_eqFunction_15(data, threadData);
  Sattraj_Master_eqFunction_16(data, threadData);
  Sattraj_Master_eqFunction_17(data, threadData);
  Sattraj_Master_eqFunction_18(data, threadData);
  Sattraj_Master_eqFunction_19(data, threadData);
  Sattraj_Master_eqFunction_20(data, threadData);
  Sattraj_Master_eqFunction_21(data, threadData);
  Sattraj_Master_eqFunction_22(data, threadData);
  Sattraj_Master_eqFunction_23(data, threadData);
  Sattraj_Master_eqFunction_24(data, threadData);
  Sattraj_Master_eqFunction_25(data, threadData);
  Sattraj_Master_eqFunction_26(data, threadData);
  Sattraj_Master_eqFunction_27(data, threadData);
  Sattraj_Master_eqFunction_28(data, threadData);
  Sattraj_Master_eqFunction_29(data, threadData);
  Sattraj_Master_eqFunction_30(data, threadData);
  Sattraj_Master_eqFunction_31(data, threadData);
  Sattraj_Master_eqFunction_32(data, threadData);
  Sattraj_Master_eqFunction_33(data, threadData);
  Sattraj_Master_eqFunction_34(data, threadData);
  TRACE_POP
}


int Sattraj_Master_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  Sattraj_Master_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Sattraj_Master_functionInitialEquations_lambda0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
int Sattraj_Master_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

