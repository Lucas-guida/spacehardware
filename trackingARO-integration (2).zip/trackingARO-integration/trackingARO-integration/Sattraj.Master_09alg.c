/* Algebraic */
#include "Sattraj.Master_model.h"

#ifdef __cplusplus
extern "C" {
#endif


/* forwarded equations */
extern void Sattraj_Master_eqFunction_38(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_44(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_45(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_46(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_47(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_48(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_49(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_50(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_51(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_54(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_55(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_56(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_57(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_58(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_59(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_60(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_61(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_62(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_63(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_64(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_65(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_66(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_37(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_36(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_35(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  Sattraj_Master_eqFunction_38(data, threadData);

  Sattraj_Master_eqFunction_44(data, threadData);

  Sattraj_Master_eqFunction_45(data, threadData);

  Sattraj_Master_eqFunction_46(data, threadData);

  Sattraj_Master_eqFunction_47(data, threadData);

  Sattraj_Master_eqFunction_48(data, threadData);

  Sattraj_Master_eqFunction_49(data, threadData);

  Sattraj_Master_eqFunction_50(data, threadData);

  Sattraj_Master_eqFunction_51(data, threadData);

  Sattraj_Master_eqFunction_54(data, threadData);

  Sattraj_Master_eqFunction_55(data, threadData);

  Sattraj_Master_eqFunction_56(data, threadData);

  Sattraj_Master_eqFunction_57(data, threadData);

  Sattraj_Master_eqFunction_58(data, threadData);

  Sattraj_Master_eqFunction_59(data, threadData);

  Sattraj_Master_eqFunction_60(data, threadData);

  Sattraj_Master_eqFunction_61(data, threadData);

  Sattraj_Master_eqFunction_62(data, threadData);

  Sattraj_Master_eqFunction_63(data, threadData);

  Sattraj_Master_eqFunction_64(data, threadData);

  Sattraj_Master_eqFunction_65(data, threadData);

  Sattraj_Master_eqFunction_66(data, threadData);

  Sattraj_Master_eqFunction_37(data, threadData);

  Sattraj_Master_eqFunction_36(data, threadData);

  Sattraj_Master_eqFunction_35(data, threadData);
}
/* for continuous time variables */
int Sattraj_Master_functionAlgebraics(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  
  data->simulationInfo->callStatistics.functionAlgebraics++;
  
  functionAlg_system0(data, threadData);

  Sattraj_Master_function_savePreSynchronous(data, threadData);
  
  TRACE_POP
  return 0;
}

#ifdef __cplusplus
}
#endif
