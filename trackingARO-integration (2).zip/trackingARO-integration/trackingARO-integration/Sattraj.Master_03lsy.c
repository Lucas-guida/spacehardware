/* Linear Systems */
#include "Sattraj.Master_model.h"
#include "Sattraj.Master_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* initial linear systems */
/* initial_lambda0 linear systems */
/* parameter linear systems */
/* model linear systems */
/* inline linear systems */
/* jacobians linear systems */


#if defined(__cplusplus)
}
#endif

