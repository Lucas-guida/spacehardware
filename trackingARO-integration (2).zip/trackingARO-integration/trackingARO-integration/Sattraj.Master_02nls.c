/* Non Linear Systems */
#include "Sattraj.Master_model.h"
#include "Sattraj.Master_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* inner equations */

void residualFunc13(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,13};
  /* iteration variables */
  data->localData[0]->realVars[24] /* GPS._E variable */ = xloc[0];
  /* backup outputs */
  /* pre body */
  /* body */
  res[0] = data->localData[0]->realVars[24] /* GPS._E variable */ + (data->simulationInfo->realParameter[7]) * (sin(data->localData[0]->realVars[24] /* GPS._E variable */)) + (-0.0174532925199433) * (data->localData[0]->realVars[0] /* GPS._M STATE(1,GPS.n) */);
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS13(NONLINEAR_SYSTEM_DATA* inSysData)
{
  /* no sparsity pattern available */
  inSysData->isPatternAvailable = 0;
}
void initializeStaticDataNLS13(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for GPS.E */
  sysData->nominal[i] = data->modelData->realVarsData[24].attribute /* GPS._E */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[24].attribute /* GPS._E */.min;
  sysData->max[i++]   = data->modelData->realVarsData[24].attribute /* GPS._E */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS13(sysData);
}

void getIterationVarsNLS13(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[24] /* GPS._E variable */;
}

/* inner equations */

/*
 equation index: 39
 type: SIMPLE_ASSIGN
 $cse9 = sin(GPS.E)
 */
void Sattraj_Master_eqFunction_39(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,39};
  data->localData[0]->realVars[17] /* $cse9 variable */ = sin(data->localData[0]->realVars[24] /* GPS._E variable */);
  TRACE_POP
}

void residualFunc44(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,44};
  /* iteration variables */
  data->localData[0]->realVars[24] /* GPS._E variable */ = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  Sattraj_Master_eqFunction_39(data, threadData);
  /* body */
  res[0] = (data->simulationInfo->realParameter[7]) * (data->localData[0]->realVars[17] /* $cse9 variable */) + data->localData[0]->realVars[24] /* GPS._E variable */ + (-0.0174532925199433) * (data->localData[0]->realVars[0] /* GPS._M STATE(1,GPS.n) */);
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS44(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = 'T';
  inSysData->sparsePattern.leadindex = (unsigned int*) malloc((1+1)*sizeof(int));
  inSysData->sparsePattern.index = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.numberOfNoneZeros = 1;
  inSysData->sparsePattern.colorCols = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.maxColors = 1;
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern.leadindex, colPtrIndex, (1+1)*sizeof(int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern.leadindex[i] += inSysData->sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern.index, rowIndex, 1*sizeof(int));
  
  /* write color array */
  inSysData->sparsePattern.colorCols[0] = 1;
}
void initializeStaticDataNLS44(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for GPS.E */
  sysData->nominal[i] = data->modelData->realVarsData[24].attribute /* GPS._E */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[24].attribute /* GPS._E */.min;
  sysData->max[i++]   = data->modelData->realVarsData[24].attribute /* GPS._E */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS44(sysData);
}

void getIterationVarsNLS44(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[24] /* GPS._E variable */;
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize non-linear systems */
void Sattraj_Master_initialNonLinearSystem(int nNonLinearSystems, NONLINEAR_SYSTEM_DATA* nonLinearSystemData)
{
  
  nonLinearSystemData[0].equationIndex = 13;
  nonLinearSystemData[0].size = 1;
  nonLinearSystemData[0].homotopySupport = 0;
  nonLinearSystemData[0].mixedSystem = 0;
  nonLinearSystemData[0].residualFunc = residualFunc13;
  nonLinearSystemData[0].strictTearingFunctionCall = NULL;
  nonLinearSystemData[0].analyticalJacobianColumn = NULL;
  nonLinearSystemData[0].initialAnalyticalJacobian = NULL;
  nonLinearSystemData[0].jacobianIndex = -1;
  nonLinearSystemData[0].initializeStaticNLSData = initializeStaticDataNLS13;
  nonLinearSystemData[0].getIterationVars = getIterationVarsNLS13;
  nonLinearSystemData[0].checkConstraints = NULL;
  
  nonLinearSystemData[1].equationIndex = 44;
  nonLinearSystemData[1].size = 1;
  nonLinearSystemData[1].homotopySupport = 0;
  nonLinearSystemData[1].mixedSystem = 0;
  nonLinearSystemData[1].residualFunc = residualFunc44;
  nonLinearSystemData[1].strictTearingFunctionCall = NULL;
  nonLinearSystemData[1].analyticalJacobianColumn = Sattraj_Master_functionJacNLSJac0_column;
  nonLinearSystemData[1].initialAnalyticalJacobian = Sattraj_Master_initialAnalyticJacobianNLSJac0;
  nonLinearSystemData[1].jacobianIndex = 0;
  nonLinearSystemData[1].initializeStaticNLSData = initializeStaticDataNLS44;
  nonLinearSystemData[1].getIterationVars = getIterationVarsNLS44;
  nonLinearSystemData[1].checkConstraints = NULL;
}

#if defined(__cplusplus)
}
#endif

