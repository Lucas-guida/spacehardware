/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "Sattraj.Master_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

int Sattraj_Master_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  /* min ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating min-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* max ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating max-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* nominal **************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating nominal-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating primary start-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  TRACE_POP
  return 0;
}


/*
 equation index: 67
 type: SIMPLE_ASSIGN
 ARO._lat = 0.0174532925199433 * ARO.latitude
 */
void Sattraj_Master_eqFunction_67(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,67};
  data->localData[0]->realVars[19] /* ARO._lat variable */ = (0.0174532925199433) * (data->simulationInfo->realParameter[1]);
  TRACE_POP
}

/*
 equation index: 68
 type: SIMPLE_ASSIGN
 $cse1 = sin(ARO.lat)
 */
void Sattraj_Master_eqFunction_68(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,68};
  data->localData[0]->realVars[9] /* $cse1 variable */ = sin(data->localData[0]->realVars[19] /* ARO._lat variable */);
  TRACE_POP
}

/*
 equation index: 69
 type: SIMPLE_ASSIGN
 $cse2 = cos(ARO.lat)
 */
void Sattraj_Master_eqFunction_69(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,69};
  data->localData[0]->realVars[10] /* $cse2 variable */ = cos(data->localData[0]->realVars[19] /* ARO._lat variable */);
  TRACE_POP
}

/*
 equation index: 70
 type: SIMPLE_ASSIGN
 ARO._long = 0.0174532925199433 * ARO.longitude
 */
void Sattraj_Master_eqFunction_70(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,70};
  data->localData[0]->realVars[20] /* ARO._long variable */ = (0.0174532925199433) * (data->simulationInfo->realParameter[2]);
  TRACE_POP
}

/*
 equation index: 71
 type: SIMPLE_ASSIGN
 $cse3 = sin(ARO.long)
 */
void Sattraj_Master_eqFunction_71(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,71};
  data->localData[0]->realVars[11] /* $cse3 variable */ = sin(data->localData[0]->realVars[20] /* ARO._long variable */);
  TRACE_POP
}

/*
 equation index: 72
 type: SIMPLE_ASSIGN
 $cse4 = cos(ARO.long)
 */
void Sattraj_Master_eqFunction_72(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,72};
  data->localData[0]->realVars[12] /* $cse4 variable */ = cos(data->localData[0]->realVars[20] /* ARO._long variable */);
  TRACE_POP
}

/*
 equation index: 73
 type: SIMPLE_ASSIGN
 theta2 = Sattraj.theta_t(din2, tm2)
 */
void Sattraj_Master_eqFunction_73(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,73};
  data->localData[0]->realVars[53] /* theta2 variable */ = omc_Sattraj_theta__t(threadData, data->simulationInfo->realParameter[11], data->simulationInfo->realParameter[15]);
  TRACE_POP
}

/*
 equation index: 74
 type: SIMPLE_ASSIGN
 GPS._v_sat_p._z = 0.0
 */
void Sattraj_Master_eqFunction_74(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,74};
  data->localData[0]->realVars[37] /* GPS._v_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 75
 type: SIMPLE_ASSIGN
 GPS._p_sat_p._z = 0.0
 */
void Sattraj_Master_eqFunction_75(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,75};
  data->localData[0]->realVars[33] /* GPS._p_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 76
 type: SIMPLE_ASSIGN
 GPS._GM = 398600.4418
 */
void Sattraj_Master_eqFunction_76(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,76};
  data->localData[0]->realVars[25] /* GPS._GM variable */ = 398600.4418;
  TRACE_POP
}

/*
 equation index: 77
 type: SIMPLE_ASSIGN
 ARO._N = DIVISION(6378137.0, sqrt(1.0 + -0.006694379990141317 * sin(ARO.lat) ^ 2.0))
 */
void Sattraj_Master_eqFunction_77(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,77};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = sin(data->localData[0]->realVars[19] /* ARO._lat variable */);
  tmp1 = 1.0 + (-0.006694379990141317) * ((tmp0 * tmp0));
  if(!(tmp1 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(1.0 + -0.006694379990141317 * sin(ARO.lat) ^ 2.0) was %g should be >= 0", tmp1);
  }
  data->localData[0]->realVars[18] /* ARO._N variable */ = DIVISION_SIM(6378137.0,sqrt(tmp1),"sqrt(1.0 + -0.006694379990141317 * sin(ARO.lat) ^ 2.0)",equationIndexes);
  TRACE_POP
}

/*
 equation index: 78
 type: SIMPLE_ASSIGN
 GPS._pi = 3.141592653589793
 */
void Sattraj_Master_eqFunction_78(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,78};
  data->localData[0]->realVars[34] /* GPS._pi variable */ = 3.141592653589793;
  TRACE_POP
}
int Sattraj_Master_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Sattraj_Master_eqFunction_67(data, threadData);

  Sattraj_Master_eqFunction_68(data, threadData);

  Sattraj_Master_eqFunction_69(data, threadData);

  Sattraj_Master_eqFunction_70(data, threadData);

  Sattraj_Master_eqFunction_71(data, threadData);

  Sattraj_Master_eqFunction_72(data, threadData);

  Sattraj_Master_eqFunction_73(data, threadData);

  Sattraj_Master_eqFunction_74(data, threadData);

  Sattraj_Master_eqFunction_75(data, threadData);

  Sattraj_Master_eqFunction_76(data, threadData);

  Sattraj_Master_eqFunction_77(data, threadData);

  Sattraj_Master_eqFunction_78(data, threadData);
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

