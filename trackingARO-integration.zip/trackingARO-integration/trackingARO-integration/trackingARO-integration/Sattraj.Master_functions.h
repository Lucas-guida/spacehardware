#ifndef Sattraj_Master__H
#define Sattraj_Master__H
#include "meta/meta_modelica.h"
#include "util/modelica.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "simulation/simulation_runtime.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct Sattraj_Vector_s {
  modelica_real _x;
  modelica_real _y;
  modelica_real _z;
} Sattraj_Vector;
typedef base_array_t Sattraj_Vector_array;
extern struct record_description Sattraj_Vector__desc;

DLLExport
Sattraj_Vector omc_Sattraj_Vector (threadData_t *threadData, modelica_real omc_x, modelica_real omc_y, modelica_real omc_z);

DLLExport
modelica_metatype boxptr_Sattraj_Vector(threadData_t *threadData, modelica_metatype _x, modelica_metatype _y, modelica_metatype _z);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Sattraj_Vector,2,0) {(void*) boxptr_Sattraj_Vector,0}};
#define boxvar_Sattraj_Vector MMC_REFSTRUCTLIT(boxvar_lit_Sattraj_Vector)


DLLExport
Sattraj_Vector omc_Sattraj_range__ECF2topo(threadData_t *threadData, Sattraj_Vector _p_sat_ecf, Sattraj_Vector _v_sat_ecf, Sattraj_Vector _p_stn_ecf, modelica_real _longitude, modelica_real _latitude, Sattraj_Vector *out_v_sat_topo);
DLLExport
modelica_metatype boxptr_Sattraj_range__ECF2topo(threadData_t *threadData, modelica_metatype _p_sat_ecf, modelica_metatype _v_sat_ecf, modelica_metatype _p_stn_ecf, modelica_metatype _longitude, modelica_metatype _latitude, modelica_metatype *out_v_sat_topo);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Sattraj_range__ECF2topo,2,0) {(void*) boxptr_Sattraj_range__ECF2topo,0}};
#define boxvar_Sattraj_range__ECF2topo MMC_REFSTRUCTLIT(boxvar_lit_Sattraj_range__ECF2topo)


DLLExport
modelica_real omc_Sattraj_range__topo2look__angles(threadData_t *threadData, modelica_real _az_vel_lim, modelica_real _el_vel_lim, Sattraj_Vector _p_sat_topo, Sattraj_Vector _v_sat_topo, modelica_real *out_elevation, modelica_real *out_dAz, modelica_real *out_dEl);
DLLExport
modelica_metatype boxptr_Sattraj_range__topo2look__angles(threadData_t *threadData, modelica_metatype _az_vel_lim, modelica_metatype _el_vel_lim, modelica_metatype _p_sat_topo, modelica_metatype _v_sat_topo, modelica_metatype *out_elevation, modelica_metatype *out_dAz, modelica_metatype *out_dEl);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Sattraj_range__topo2look__angles,2,0) {(void*) boxptr_Sattraj_range__topo2look__angles,0}};
#define boxvar_Sattraj_range__topo2look__angles MMC_REFSTRUCTLIT(boxvar_lit_Sattraj_range__topo2look__angles)


DLLExport
Sattraj_Vector omc_Sattraj_sat__ECF(threadData_t *threadData, Sattraj_Vector _p_sat_eci, Sattraj_Vector _v_sat_eci, modelica_real _theta_t, Sattraj_Vector *out_v_sat_ecf);
DLLExport
modelica_metatype boxptr_Sattraj_sat__ECF(threadData_t *threadData, modelica_metatype _p_sat_eci, modelica_metatype _v_sat_eci, modelica_metatype _theta_t, modelica_metatype *out_v_sat_ecf);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Sattraj_sat__ECF,2,0) {(void*) boxptr_Sattraj_sat__ECF,0}};
#define boxvar_Sattraj_sat__ECF MMC_REFSTRUCTLIT(boxvar_lit_Sattraj_sat__ECF)


DLLExport
Sattraj_Vector omc_Sattraj_sat__ECI(threadData_t *threadData, Sattraj_Vector _p_sat_pf, Sattraj_Vector _v_sat_pf, modelica_real _ecc, modelica_real _raan, modelica_real _inc, modelica_real _argper, modelica_real _N, Sattraj_Vector *out_v_sat_eci);
DLLExport
modelica_metatype boxptr_Sattraj_sat__ECI(threadData_t *threadData, modelica_metatype _p_sat_pf, modelica_metatype _v_sat_pf, modelica_metatype _ecc, modelica_metatype _raan, modelica_metatype _inc, modelica_metatype _argper, modelica_metatype _N, modelica_metatype *out_v_sat_eci);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Sattraj_sat__ECI,2,0) {(void*) boxptr_Sattraj_sat__ECI,0}};
#define boxvar_Sattraj_sat__ECI MMC_REFSTRUCTLIT(boxvar_lit_Sattraj_sat__ECI)


DLLExport
modelica_real omc_Sattraj_theta__t(threadData_t *threadData, modelica_real _din, modelica_real _tm);
DLLExport
modelica_metatype boxptr_Sattraj_theta__t(threadData_t *threadData, modelica_metatype _din, modelica_metatype _tm);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Sattraj_theta__t,2,0) {(void*) boxptr_Sattraj_theta__t,0}};
#define boxvar_Sattraj_theta__t MMC_REFSTRUCTLIT(boxvar_lit_Sattraj_theta__t)
#include "Sattraj.Master_model.h"


#ifdef __cplusplus
}
#endif
#endif

