from OMPython import ModelicaSystem

print('0.' + '92343')


