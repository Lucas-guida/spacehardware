/* Linearization */
#include "Sattraj.Master_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *Sattraj_Master_linear_model_frame()
{
  return "model linear_Sattraj_Master\n  parameter Integer n = 1; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 5; // top-level outputs\n"
  "  parameter Real x0[1] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real A[1,1] = [%s];\n"
  "  parameter Real B[1,0] = zeros(1,0);%s\n"
  "  parameter Real C[5,1] = [%s];\n"
  "  parameter Real D[5,0] = zeros(5,0);%s\n"
  "  Real x[1](start=x0);\n"
  "  input Real u[0];\n"
  "  output Real y[5];\n"
  "\n  Real 'x_GPS.M' = x[1];\nReal 'y_azimuth2' = y[1];\nReal 'y_dAz2' = y[2];\nReal 'y_dEl2' = y[3];\nReal 'y_elevation2' = y[4];\nReal 'y_theta2' = y[5];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linear_Sattraj_Master;\n";
}
const char *Sattraj_Master_linear_model_datarecovery_frame()
{
  return "model linear_Sattraj_Master\n  parameter Integer n = 1; // states\n  parameter Integer k = 0; // top-level inputs\n  parameter Integer l = 5; // top-level outputs\n  parameter Integer nz = 61; // data recovery variables\n"
  "  parameter Real x0[1] = {%s};\n"
  "  parameter Real u0[0] = {%s};\n"
  "  parameter Real z0[61] = {%s};\n"
  "  parameter Real A[1,1] = [%s];\n"
  "  parameter Real B[1,0] = zeros(1,0);%s\n"
  "  parameter Real C[5,1] = [%s];\n"
  "  parameter Real D[5,0] = zeros(5,0);%s\n"
  "  parameter Real Cz[61,1] = [%s];\n"
  "  parameter Real Dz[61,0] = zeros(61,0);%s\n"
  "  Real x[1](start=x0);\n"
  "  input Real u[0];\n"
  "  output Real y[5];\n"
  "  output Real z[61];\n"
  "\nReal 'x_GPS.M' = x[1];\nReal 'y_azimuth2' = y[1];\nReal 'y_dAz2' = y[2];\nReal 'y_dEl2' = y[3];\nReal 'y_elevation2' = y[4];\nReal 'y_theta2' = y[5];\nReal 'z_$TMP$VAR$14$0ATAN$TAN' = z[1];\nReal 'z_$TMP$VAR$14$0PREX$TAN' = z[2];\nReal 'z_$TMP$VAR$14$0Y$TAN' = z[3];\nReal 'z_$TMP$VAR$21$0X$ABS' = z[4];\nReal 'z_$TMP$VAR$47$0ATAN$TAN' = z[5];\nReal 'z_$TMP$VAR$47$0PREX$TAN' = z[6];\nReal 'z_$TMP$VAR$58$0X$ABS' = z[7];\nReal 'z_$cse1' = z[8];\nReal 'z_$cse2' = z[9];\nReal 'z_$cse3' = z[10];\nReal 'z_$cse4' = z[11];\nReal 'z_$cse5' = z[12];\nReal 'z_$cse6' = z[13];\nReal 'z_$cse7' = z[14];\nReal 'z_$cse8' = z[15];\nReal 'z_$cse9' = z[16];\nReal 'z_ARO.N' = z[17];\nReal 'z_ARO.lat' = z[18];\nReal 'z_ARO.long' = z[19];\nReal 'z_ARO.x' = z[20];\nReal 'z_ARO.y' = z[21];\nReal 'z_ARO.z' = z[22];\nReal 'z_GPS.E' = z[23];\nReal 'z_GPS.GM' = z[24];\nReal 'z_GPS.Mean' = z[25];\nReal 'z_GPS.a' = z[26];\nReal 'z_GPS.dr' = z[27];\nReal 'z_GPS.dx' = z[28];\nReal 'z_GPS.dy' = z[29];\nReal 'z_GPS.h' = z[30];\nReal 'z_GPS.n' = z[31];\nReal 'z_GPS.p_sat_p.z' = z[32];\nReal 'z_GPS.pi' = z[33];\nReal 'z_GPS.r' = z[34];\nReal 'z_GPS.theta' = z[35];\nReal 'z_GPS.v_sat_p.z' = z[36];\nReal 'z_GPS.x' = z[37];\nReal 'z_GPS.y' = z[38];\nReal 'z_azimuth2' = z[39];\nReal 'z_dAz2' = z[40];\nReal 'z_dEl2' = z[41];\nReal 'z_elevation2' = z[42];\nReal 'z_p.x' = z[43];\nReal 'z_p.y' = z[44];\nReal 'z_p.z' = z[45];\nReal 'z_p2.x' = z[46];\nReal 'z_p2.y' = z[47];\nReal 'z_p2.z' = z[48];\nReal 'z_p3.x' = z[49];\nReal 'z_p3.y' = z[50];\nReal 'z_p3.z' = z[51];\nReal 'z_theta2' = z[52];\nReal 'z_v.x' = z[53];\nReal 'z_v.y' = z[54];\nReal 'z_v.z' = z[55];\nReal 'z_v2.x' = z[56];\nReal 'z_v2.y' = z[57];\nReal 'z_v2.z' = z[58];\nReal 'z_v3.x' = z[59];\nReal 'z_v3.y' = z[60];\nReal 'z_v3.z' = z[61];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linear_Sattraj_Master;\n";
}
#if defined(__cplusplus)
}
#endif

