/* Main Simulation File */
#include "Sattraj.Master_model.h"

#define prefixedName_performSimulation Sattraj_Master_performSimulation
#define prefixedName_updateContinuousSystem Sattraj_Master_updateContinuousSystem
#include <simulation/solver/perform_simulation.c>

#define prefixedName_performQSSSimulation Sattraj_Master_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c>

/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int Sattraj_Master_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Master_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Master_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Master_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Master_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->outputVars[0] = data->localData[0]->realVars[40] /* azimuth2 variable */;
  data->simulationInfo->outputVars[1] = data->localData[0]->realVars[41] /* dAz2 variable */;
  data->simulationInfo->outputVars[2] = data->localData[0]->realVars[42] /* dEl2 variable */;
  data->simulationInfo->outputVars[3] = data->localData[0]->realVars[43] /* elevation2 variable */;
  data->simulationInfo->outputVars[4] = data->localData[0]->realVars[53] /* theta2 variable */;
  
  TRACE_POP
  return 0;
}


/*
 equation index: 35
 type: SIMPLE_ASSIGN
 ARO._x = (ARO.N + ARO.elevation) * $cse2 * $cse4
 */
void Sattraj_Master_eqFunction_35(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,35};
  data->localData[0]->realVars[21] /* ARO._x variable */ = (data->localData[0]->realVars[18] /* ARO._N variable */ + data->simulationInfo->realParameter[0]) * ((data->localData[0]->realVars[10] /* $cse2 variable */) * (data->localData[0]->realVars[12] /* $cse4 variable */));
  TRACE_POP
}
/*
 equation index: 36
 type: SIMPLE_ASSIGN
 ARO._y = (ARO.N + ARO.elevation) * $cse2 * $cse3
 */
void Sattraj_Master_eqFunction_36(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,36};
  data->localData[0]->realVars[22] /* ARO._y variable */ = (data->localData[0]->realVars[18] /* ARO._N variable */ + data->simulationInfo->realParameter[0]) * ((data->localData[0]->realVars[10] /* $cse2 variable */) * (data->localData[0]->realVars[11] /* $cse3 variable */));
  TRACE_POP
}
/*
 equation index: 37
 type: SIMPLE_ASSIGN
 ARO._z = (0.9933056200098587 * ARO.N + ARO.elevation) * $cse1
 */
void Sattraj_Master_eqFunction_37(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,37};
  data->localData[0]->realVars[23] /* ARO._z variable */ = ((0.9933056200098587) * (data->localData[0]->realVars[18] /* ARO._N variable */) + data->simulationInfo->realParameter[0]) * (data->localData[0]->realVars[9] /* $cse1 variable */);
  TRACE_POP
}
/*
 equation index: 38
 type: SIMPLE_ASSIGN
 GPS._Mean = mod(GPS.M, 360.0, 0)
 */
void Sattraj_Master_eqFunction_38(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,38};
  data->localData[0]->realVars[26] /* GPS._Mean variable */ = _event_mod_real(data->localData[0]->realVars[0] /* GPS._M STATE(1,GPS.n) */, 360.0, ((modelica_integer) 0), data, threadData);
  TRACE_POP
}
void Sattraj_Master_eqFunction_39(DATA*,threadData_t*);
void Sattraj_Master_eqFunction_40(DATA*,threadData_t*);
/*
 equation index: 44
 indexNonlinear: 1
 type: NONLINEAR
 
 vars: {GPS._E}
 eqns: {39, 40}
 */
void Sattraj_Master_eqFunction_44(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,44};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 44 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[1].nlsxOld[0] = data->localData[0]->realVars[24] /* GPS._E variable */;
  retValue = solve_nonlinear_system(data, threadData, 1);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,44};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 44 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[24] /* GPS._E variable */ = data->simulationInfo->nonlinearSystemData[1].nlsx[0];
  TRACE_POP
}
/*
 equation index: 45
 type: SIMPLE_ASSIGN
 $cse7 = tan(0.5 * GPS.E)
 */
void Sattraj_Master_eqFunction_45(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,45};
  data->localData[0]->realVars[15] /* $cse7 variable */ = tan((0.5) * (data->localData[0]->realVars[24] /* GPS._E variable */));
  TRACE_POP
}
/*
 equation index: 46
 type: SIMPLE_ASSIGN
 $cse8 = DIVISION($cse7, sqrt(DIVISION(1.0 - GPS.ecc, 1.0 + GPS.ecc)))
 */
void Sattraj_Master_eqFunction_46(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,46};
  modelica_real tmp0;
  tmp0 = DIVISION_SIM(1.0 - data->simulationInfo->realParameter[7],1.0 + data->simulationInfo->realParameter[7],"1.0 + GPS.ecc",equationIndexes);
  if(!(tmp0 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(DIVISION(1.0 - GPS.ecc, 1.0 + GPS.ecc)) was %g should be >= 0", tmp0);
  }
  data->localData[0]->realVars[16] /* $cse8 variable */ = DIVISION_SIM(data->localData[0]->realVars[15] /* $cse7 variable */,sqrt(tmp0),"sqrt(DIVISION(1.0 - GPS.ecc, 1.0 + GPS.ecc))",equationIndexes);
  TRACE_POP
}
/*
 equation index: 47
 type: SIMPLE_ASSIGN
 $TMP$VAR$47$0ATAN$TAN = atan($cse8)
 */
void Sattraj_Master_eqFunction_47(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,47};
  data->localData[0]->realVars[6] /* $TMP$VAR$47$0ATAN$TAN variable */ = atan(data->localData[0]->realVars[16] /* $cse8 variable */);
  TRACE_POP
}
/*
 equation index: 48
 type: SIMPLE_ASSIGN
 $TMP$VAR$47$0PREX$TAN = if initial() then if pre(GPS.theta) == 0.0 then 1.0 else 0.5 * pre(GPS.theta) else 0.5 * pre(GPS.theta)
 */
void Sattraj_Master_eqFunction_48(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,48};
  data->localData[0]->realVars[7] /* $TMP$VAR$47$0PREX$TAN variable */ = (initial()?((data->simulationInfo->realVarsPre[36] /* GPS._theta variable */ == 0.0)?1.0:(0.5) * (data->simulationInfo->realVarsPre[36] /* GPS._theta variable */)):(0.5) * (data->simulationInfo->realVarsPre[36] /* GPS._theta variable */));
  TRACE_POP
}
/*
 equation index: 49
 type: SIMPLE_ASSIGN
 GPS._theta = 2.0 * $TMP$VAR$47$0ATAN$TAN + 6.283185307179586 * $_round(($TMP$VAR$47$0PREX$TAN - $TMP$VAR$47$0ATAN$TAN) / 3.141592653589793)
 */
void Sattraj_Master_eqFunction_49(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,49};
  modelica_real tmp2;
  tmp2 = 3.141592653589793;
  if (tmp2 == 0) {throwStreamPrint(threadData, "Division by zero %s", "($TMP$VAR$47$0PREX$TAN - $TMP$VAR$47$0ATAN$TAN) / 3.141592653589793");}
  data->localData[0]->realVars[36] /* GPS._theta variable */ = (2.0) * (data->localData[0]->realVars[6] /* $TMP$VAR$47$0ATAN$TAN variable */) + (6.283185307179586) * (((modelica_integer)round((modelica_real)((data->localData[0]->realVars[7] /* $TMP$VAR$47$0PREX$TAN variable */ - data->localData[0]->realVars[6] /* $TMP$VAR$47$0ATAN$TAN variable */) / tmp2))));
  TRACE_POP
}
/*
 equation index: 50
 type: SIMPLE_ASSIGN
 $cse6 = sin(GPS.theta)
 */
void Sattraj_Master_eqFunction_50(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,50};
  data->localData[0]->realVars[14] /* $cse6 variable */ = sin(data->localData[0]->realVars[36] /* GPS._theta variable */);
  TRACE_POP
}
/*
 equation index: 51
 type: SIMPLE_ASSIGN
 $cse5 = cos(GPS.theta)
 */
void Sattraj_Master_eqFunction_51(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,51};
  data->localData[0]->realVars[13] /* $cse5 variable */ = cos(data->localData[0]->realVars[36] /* GPS._theta variable */);
  TRACE_POP
}
/*
 equation index: 52
 type: SIMPLE_ASSIGN
 GPS._n = 0.004166666666666667 * GPS.N0 + 9.645061728395061e-008 * GPS.Ndot2 * time + 1.674489883401921e-012 * GPS.Nddot6 * time ^ 2.0
 */
void Sattraj_Master_eqFunction_52(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,52};
  modelica_real tmp3;
  tmp3 = data->localData[0]->timeValue;
  data->localData[0]->realVars[32] /* GPS._n variable */ = (0.004166666666666667) * (data->simulationInfo->realParameter[4]) + (9.645061728395061e-008) * ((data->simulationInfo->realParameter[6]) * (data->localData[0]->timeValue)) + (1.674489883401921e-012) * ((data->simulationInfo->realParameter[5]) * ((tmp3 * tmp3)));
  TRACE_POP
}
/*
 equation index: 53
 type: SIMPLE_ASSIGN
 der(GPS._M) = GPS.n
 */
void Sattraj_Master_eqFunction_53(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,53};
  data->localData[0]->realVars[1] /* der(GPS._M) STATE_DER */ = data->localData[0]->realVars[32] /* GPS._n variable */;
  TRACE_POP
}
/*
 equation index: 54
 type: SIMPLE_ASSIGN
 GPS._a = DIVISION(398600.4418, (-0.0174532925199433 * GPS.n) ^ 2.0) ^ 0.3333333333333333
 */
void Sattraj_Master_eqFunction_54(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,54};
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_real tmp10;
  modelica_real tmp11;
  tmp4 = (-0.0174532925199433) * (data->localData[0]->realVars[32] /* GPS._n variable */);
  tmp5 = DIVISION_SIM(398600.4418,(tmp4 * tmp4),"(-0.0174532925199433 * GPS.n) ^ 2.0",equationIndexes);
  tmp6 = 0.3333333333333333;
  if(tmp5 < 0.0 && tmp6 != 0.0)
  {
    tmp8 = modf(tmp6, &tmp9);
    
    if(tmp8 > 0.5)
    {
      tmp8 -= 1.0;
      tmp9 += 1.0;
    }
    else if(tmp8 < -0.5)
    {
      tmp8 += 1.0;
      tmp9 -= 1.0;
    }
    
    if(fabs(tmp8) < 1e-10)
      tmp7 = pow(tmp5, tmp9);
    else
    {
      tmp11 = modf(1.0/tmp6, &tmp10);
      if(tmp11 > 0.5)
      {
        tmp11 -= 1.0;
        tmp10 += 1.0;
      }
      else if(tmp11 < -0.5)
      {
        tmp11 += 1.0;
        tmp10 -= 1.0;
      }
      if(fabs(tmp11) < 1e-10 && ((unsigned long)tmp10 & 1))
      {
        tmp7 = -pow(-tmp5, tmp8)*pow(tmp5, tmp9);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp5, tmp6);
      }
    }
  }
  else
  {
    tmp7 = pow(tmp5, tmp6);
  }
  if(isnan(tmp7) || isinf(tmp7))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp5, tmp6);
  }
  data->localData[0]->realVars[27] /* GPS._a variable */ = tmp7;
  TRACE_POP
}
/*
 equation index: 55
 type: SIMPLE_ASSIGN
 GPS._r = GPS.a * DIVISION(1.0 - GPS.ecc ^ 2.0, 1.0 + GPS.ecc * $cse5)
 */
void Sattraj_Master_eqFunction_55(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,55};
  modelica_real tmp12;
  tmp12 = data->simulationInfo->realParameter[7];
  data->localData[0]->realVars[35] /* GPS._r variable */ = (data->localData[0]->realVars[27] /* GPS._a variable */) * (DIVISION_SIM(1.0 - ((tmp12 * tmp12)),1.0 + (data->simulationInfo->realParameter[7]) * (data->localData[0]->realVars[13] /* $cse5 variable */),"1.0 + GPS.ecc * $cse5",equationIndexes));
  TRACE_POP
}
/*
 equation index: 56
 type: SIMPLE_ASSIGN
 GPS._x = GPS.r * $cse5
 */
void Sattraj_Master_eqFunction_56(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,56};
  data->localData[0]->realVars[38] /* GPS._x variable */ = (data->localData[0]->realVars[35] /* GPS._r variable */) * (data->localData[0]->realVars[13] /* $cse5 variable */);
  TRACE_POP
}
/*
 equation index: 57
 type: SIMPLE_ASSIGN
 GPS._y = GPS.r * $cse6
 */
void Sattraj_Master_eqFunction_57(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,57};
  data->localData[0]->realVars[39] /* GPS._y variable */ = (data->localData[0]->realVars[35] /* GPS._r variable */) * (data->localData[0]->realVars[14] /* $cse6 variable */);
  TRACE_POP
}
/*
 equation index: 58
 type: SIMPLE_ASSIGN
 $TMP$VAR$58$0X$ABS = pre(GPS.h)
 */
void Sattraj_Master_eqFunction_58(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,58};
  data->localData[0]->realVars[8] /* $TMP$VAR$58$0X$ABS variable */ = data->simulationInfo->realVarsPre[31] /* GPS._h variable */;
  TRACE_POP
}
/*
 equation index: 59
 type: SIMPLE_ASSIGN
 GPS._h = $_signNoNull($TMP$VAR$58$0X$ABS) * abs(-398600.4418 ^ 0.5 * (-GPS.r) ^ 0.5 * (1.0 + GPS.ecc * $cse5) ^ 0.5)
 */
void Sattraj_Master_eqFunction_59(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,59};
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_real tmp15;
  tmp13 = -398600.4418;
  if(!(tmp13 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-398600.4418) was %g should be >= 0", tmp13);
  }tmp14 = (-data->localData[0]->realVars[35] /* GPS._r variable */);
  if(!(tmp14 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-GPS.r) was %g should be >= 0", tmp14);
  }tmp15 = 1.0 + (data->simulationInfo->realParameter[7]) * (data->localData[0]->realVars[13] /* $cse5 variable */);
  if(!(tmp15 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(1.0 + GPS.ecc * $cse5) was %g should be >= 0", tmp15);
  }
  data->localData[0]->realVars[31] /* GPS._h variable */ = ((data->localData[0]->realVars[8] /* $TMP$VAR$58$0X$ABS variable */ >= 0.0 ? 1.0:-1.0)) * (fabs((sqrt(tmp13)) * ((sqrt(tmp14)) * (sqrt(tmp15)))));
  TRACE_POP
}
/*
 equation index: 60
 type: SIMPLE_ASSIGN
 GPS._dr = 398600.4418 * GPS.ecc * DIVISION($cse6, GPS.h)
 */
void Sattraj_Master_eqFunction_60(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,60};
  data->localData[0]->realVars[28] /* GPS._dr variable */ = (398600.4418) * ((data->simulationInfo->realParameter[7]) * (DIVISION_SIM(data->localData[0]->realVars[14] /* $cse6 variable */,data->localData[0]->realVars[31] /* GPS._h variable */,"GPS.h",equationIndexes)));
  TRACE_POP
}
/*
 equation index: 61
 type: SIMPLE_ASSIGN
 GPS._dx = -398600.4418 * DIVISION($cse6, GPS.h)
 */
void Sattraj_Master_eqFunction_61(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,61};
  data->localData[0]->realVars[29] /* GPS._dx variable */ = (-398600.4418) * (DIVISION_SIM(data->localData[0]->realVars[14] /* $cse6 variable */,data->localData[0]->realVars[31] /* GPS._h variable */,"GPS.h",equationIndexes));
  TRACE_POP
}
/*
 equation index: 62
 type: SIMPLE_ASSIGN
 GPS._dy = 398600.4418 * DIVISION(GPS.ecc + $cse5, GPS.h)
 */
void Sattraj_Master_eqFunction_62(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,62};
  data->localData[0]->realVars[30] /* GPS._dy variable */ = (398600.4418) * (DIVISION_SIM(data->simulationInfo->realParameter[7] + data->localData[0]->realVars[13] /* $cse5 variable */,data->localData[0]->realVars[31] /* GPS._h variable */,"GPS.h",equationIndexes));
  TRACE_POP
}
/*
 equation index: 63
 type: ALGORITHM
 
   (p, v) := Sattraj.sat_ECI(Sattraj.Vector(GPS.x, GPS.y, 0.0), Sattraj.Vector(GPS.dx, GPS.dy, 0.0), GPS.ecc, raan2, inc2, argper2, GPS.N0);
 */
void Sattraj_Master_eqFunction_63(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,63};
  Sattraj_Vector tmp16;
  Sattraj_Vector tmp17;
  tmp17 = omc_Sattraj_sat__ECI(threadData, omc_Sattraj_Vector(threadData, data->localData[0]->realVars[38] /* GPS._x variable */, data->localData[0]->realVars[39] /* GPS._y variable */, 0.0), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[29] /* GPS._dx variable */, data->localData[0]->realVars[30] /* GPS._dy variable */, 0.0), data->simulationInfo->realParameter[7], data->simulationInfo->realParameter[14], data->simulationInfo->realParameter[13], data->simulationInfo->realParameter[9], data->simulationInfo->realParameter[4] ,&tmp16);
  data->localData[0]->realVars[44] /* p._x variable */ = tmp17._x;
  data->localData[0]->realVars[45] /* p._y variable */ = tmp17._y;
  data->localData[0]->realVars[46] /* p._z variable */ = tmp17._z;
  data->localData[0]->realVars[54] /* v._x variable */ = tmp16._x;
  data->localData[0]->realVars[55] /* v._y variable */ = tmp16._y;
  data->localData[0]->realVars[56] /* v._z variable */ = tmp16._z;
  TRACE_POP
}
/*
 equation index: 64
 type: ALGORITHM
 
   (p2, v2) := Sattraj.sat_ECF(p, v, theta2);
 */
void Sattraj_Master_eqFunction_64(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,64};
  Sattraj_Vector tmp18;
  Sattraj_Vector tmp19;
  tmp19 = omc_Sattraj_sat__ECF(threadData, omc_Sattraj_Vector(threadData, data->localData[0]->realVars[44] /* p._x variable */, data->localData[0]->realVars[45] /* p._y variable */, data->localData[0]->realVars[46] /* p._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[54] /* v._x variable */, data->localData[0]->realVars[55] /* v._y variable */, data->localData[0]->realVars[56] /* v._z variable */), data->localData[0]->realVars[53] /* theta2 variable */ ,&tmp18);
  data->localData[0]->realVars[47] /* p2._x variable */ = tmp19._x;
  data->localData[0]->realVars[48] /* p2._y variable */ = tmp19._y;
  data->localData[0]->realVars[49] /* p2._z variable */ = tmp19._z;
  data->localData[0]->realVars[57] /* v2._x variable */ = tmp18._x;
  data->localData[0]->realVars[58] /* v2._y variable */ = tmp18._y;
  data->localData[0]->realVars[59] /* v2._z variable */ = tmp18._z;
  TRACE_POP
}
/*
 equation index: 65
 type: ALGORITHM
 
   (p3, v3) := Sattraj.range_ECF2topo(p2, v2, Sattraj.Vector(ARO.x, ARO.y, ARO.z), ARO.longitude, ARO.latitude);
 */
void Sattraj_Master_eqFunction_65(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,65};
  Sattraj_Vector tmp20;
  Sattraj_Vector tmp21;
  tmp21 = omc_Sattraj_range__ECF2topo(threadData, omc_Sattraj_Vector(threadData, data->localData[0]->realVars[47] /* p2._x variable */, data->localData[0]->realVars[48] /* p2._y variable */, data->localData[0]->realVars[49] /* p2._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[57] /* v2._x variable */, data->localData[0]->realVars[58] /* v2._y variable */, data->localData[0]->realVars[59] /* v2._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[21] /* ARO._x variable */, data->localData[0]->realVars[22] /* ARO._y variable */, data->localData[0]->realVars[23] /* ARO._z variable */), data->simulationInfo->realParameter[2], data->simulationInfo->realParameter[1] ,&tmp20);
  data->localData[0]->realVars[50] /* p3._x variable */ = tmp21._x;
  data->localData[0]->realVars[51] /* p3._y variable */ = tmp21._y;
  data->localData[0]->realVars[52] /* p3._z variable */ = tmp21._z;
  data->localData[0]->realVars[60] /* v3._x variable */ = tmp20._x;
  data->localData[0]->realVars[61] /* v3._y variable */ = tmp20._y;
  data->localData[0]->realVars[62] /* v3._z variable */ = tmp20._z;
  TRACE_POP
}
/*
 equation index: 66
 type: ALGORITHM
 
   (azimuth2, elevation2, dAz2, dEl2) := Sattraj.range_topo2look_angles(az_vel_lim2, el_vel_lim2, p, v);
 */
void Sattraj_Master_eqFunction_66(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,66};
  data->localData[0]->realVars[40] /* azimuth2 variable */ = omc_Sattraj_range__topo2look__angles(threadData, data->simulationInfo->realParameter[10], data->simulationInfo->realParameter[12], omc_Sattraj_Vector(threadData, data->localData[0]->realVars[44] /* p._x variable */, data->localData[0]->realVars[45] /* p._y variable */, data->localData[0]->realVars[46] /* p._z variable */), omc_Sattraj_Vector(threadData, data->localData[0]->realVars[54] /* v._x variable */, data->localData[0]->realVars[55] /* v._y variable */, data->localData[0]->realVars[56] /* v._z variable */) ,&data->localData[0]->realVars[43] /* elevation2 variable */ ,&data->localData[0]->realVars[41] /* dAz2 variable */ ,&data->localData[0]->realVars[42] /* dEl2 variable */);
  TRACE_POP
}


int Sattraj_Master_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  Sattraj_Master_functionLocalKnownVars(data, threadData);
  Sattraj_Master_eqFunction_35(data, threadData);

  Sattraj_Master_eqFunction_36(data, threadData);

  Sattraj_Master_eqFunction_37(data, threadData);

  Sattraj_Master_eqFunction_38(data, threadData);

  Sattraj_Master_eqFunction_44(data, threadData);

  Sattraj_Master_eqFunction_45(data, threadData);

  Sattraj_Master_eqFunction_46(data, threadData);

  Sattraj_Master_eqFunction_47(data, threadData);

  Sattraj_Master_eqFunction_48(data, threadData);

  Sattraj_Master_eqFunction_49(data, threadData);

  Sattraj_Master_eqFunction_50(data, threadData);

  Sattraj_Master_eqFunction_51(data, threadData);

  Sattraj_Master_eqFunction_52(data, threadData);

  Sattraj_Master_eqFunction_53(data, threadData);

  Sattraj_Master_eqFunction_54(data, threadData);

  Sattraj_Master_eqFunction_55(data, threadData);

  Sattraj_Master_eqFunction_56(data, threadData);

  Sattraj_Master_eqFunction_57(data, threadData);

  Sattraj_Master_eqFunction_58(data, threadData);

  Sattraj_Master_eqFunction_59(data, threadData);

  Sattraj_Master_eqFunction_60(data, threadData);

  Sattraj_Master_eqFunction_61(data, threadData);

  Sattraj_Master_eqFunction_62(data, threadData);

  Sattraj_Master_eqFunction_63(data, threadData);

  Sattraj_Master_eqFunction_64(data, threadData);

  Sattraj_Master_eqFunction_65(data, threadData);

  Sattraj_Master_eqFunction_66(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Sattraj_Master_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/* forwarded equations */
extern void Sattraj_Master_eqFunction_52(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_53(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  Sattraj_Master_eqFunction_52(data, threadData);

  Sattraj_Master_eqFunction_53(data, threadData);
}

int Sattraj_Master_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  Sattraj_Master_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "Sattraj.Master_12jac.h"
#include "Sattraj.Master_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks Sattraj_Master_callback = {
   (int (*)(DATA *, threadData_t *, void *)) Sattraj_Master_performSimulation,
   (int (*)(DATA *, threadData_t *, void *)) Sattraj_Master_performQSSSimulation,
   Sattraj_Master_updateContinuousSystem,
   Sattraj_Master_callExternalObjectDestructors,
   Sattraj_Master_initialNonLinearSystem,
   NULL,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   Sattraj_Master_initializeStateSets,
   #else
   NULL,
   #endif
   Sattraj_Master_initializeDAEmodeData,
   Sattraj_Master_functionODE,
   Sattraj_Master_functionAlgebraics,
   Sattraj_Master_functionDAE,
   Sattraj_Master_functionLocalKnownVars,
   Sattraj_Master_input_function,
   Sattraj_Master_input_function_init,
   Sattraj_Master_input_function_updateStartValues,
   Sattraj_Master_output_function,
   Sattraj_Master_function_storeDelayed,
   Sattraj_Master_updateBoundVariableAttributes,
   Sattraj_Master_functionInitialEquations,
   0,
   Sattraj_Master_functionInitialEquations_lambda0,
   Sattraj_Master_functionRemovedInitialEquations,
   Sattraj_Master_updateBoundParameters,
   Sattraj_Master_checkForAsserts,
   Sattraj_Master_function_ZeroCrossingsEquations,
   Sattraj_Master_function_ZeroCrossings,
   Sattraj_Master_function_updateRelations,
   Sattraj_Master_checkForDiscreteChanges,
   Sattraj_Master_zeroCrossingDescription,
   Sattraj_Master_relationDescription,
   Sattraj_Master_function_initSample,
   Sattraj_Master_INDEX_JAC_A,
   Sattraj_Master_INDEX_JAC_B,
   Sattraj_Master_INDEX_JAC_C,
   Sattraj_Master_INDEX_JAC_D,
   Sattraj_Master_initialAnalyticJacobianA,
   Sattraj_Master_initialAnalyticJacobianB,
   Sattraj_Master_initialAnalyticJacobianC,
   Sattraj_Master_initialAnalyticJacobianD,
   Sattraj_Master_functionJacA_column,
   Sattraj_Master_functionJacB_column,
   Sattraj_Master_functionJacC_column,
   Sattraj_Master_functionJacD_column,
   Sattraj_Master_linear_model_frame,
   Sattraj_Master_linear_model_datarecovery_frame,
   Sattraj_Master_mayer,
   Sattraj_Master_lagrange,
   Sattraj_Master_pickUpBoundsForInputsInOptimization,
   Sattraj_Master_setInputData,
   Sattraj_Master_getTimeGrid,
   Sattraj_Master_symbolicInlineSystem,
   Sattraj_Master_function_initSynchronous,
   Sattraj_Master_function_updateSynchronous,
   Sattraj_Master_function_equationsSynchronous,
   NULL
   #ifdef FMU_EXPERIMENTAL
   ,Sattraj_Master_functionODE_Partial
   ,Sattraj_Master_functionFMIJacobian
   #endif
   ,Sattraj_Master_inputNames


};

void Sattraj_Master_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &Sattraj_Master_callback;
  data->modelData->modelName = "Sattraj.Master";
  data->modelData->modelFilePrefix = "Sattraj.Master";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/admin/Desktop/trackingARO-integration/trackingARO-integration";
  data->modelData->modelGUID = "{b3137870-83c7-4e1c-b808-4d9c6bf72a67}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "Sattraj.Master_init.c"
    ;
  static const char contents_info[] =
    #include "Sattraj.Master_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "Sattraj.Master_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "Sattraj.Master_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  
  data->modelData->nStates = 1;
  data->modelData->nVariablesReal = 63;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 16;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 5;
  
  data->modelData->nAliasReal = 7;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 1;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 0;
  data->modelData->nMathEvents = 2;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "Sattraj.Master_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 6;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 79;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 2;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 5;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
int main(int argc, char**argv)
{
  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    Sattraj_Master_setupDataStruc(&data, threadData);
    res = _main_SimulationRuntime(argc, argv, &data, threadData);
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  EXIT(res);
  return res;
}

