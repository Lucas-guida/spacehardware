/* Jacobians */
static const REAL_ATTRIBUTE dummyREAL_ATTRIBUTE = omc_dummyRealAttribute;
/* Jacobian Variables */
#if defined(__cplusplus)
extern "C" {
#endif
  #define Sattraj_Satellite_INDEX_JAC_NLSJac0 0
  int Sattraj_Satellite_functionJacNLSJac0_column(void* data, threadData_t *threadData);
  int Sattraj_Satellite_initialAnalyticJacobianNLSJac0(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* NLSJac0 */
#define $PESeedNLSJac0 data->simulationInfo->analyticJacobians[0].seedVars[0]
#define _$P$cse5$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].tmpVars[0]
#define $P$cse5$P$pDERNLSJac0$PdummyVarNLSJac0 _$P$cse5$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$P$res$P1$P$pDERNLSJac0$PdummyVarNLSJac0(i) data->simulationInfo->analyticJacobians[0].resultVars[0]
#define $P$res$P1$P$pDERNLSJac0$PdummyVarNLSJac0 _$P$res$P1$P$pDERNLSJac0$PdummyVarNLSJac0(0)

#define _$P$cse6(i) data->simulationInfo->analyticJacobians[0].tmpVars[2]
#define $P$cse6 _$P$cse6(0)

#if defined(__cplusplus)
extern "C" {
#endif
  #define Sattraj_Satellite_INDEX_JAC_A 4
  int Sattraj_Satellite_functionJacA_column(void* data, threadData_t *threadData);
  int Sattraj_Satellite_initialAnalyticJacobianA(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* A */
#define $PMSeedA data->simulationInfo->analyticJacobians[4].seedVars[0]

#if defined(__cplusplus)
extern "C" {
#endif
  #define Sattraj_Satellite_INDEX_JAC_B 3
  int Sattraj_Satellite_functionJacB_column(void* data, threadData_t *threadData);
  int Sattraj_Satellite_initialAnalyticJacobianB(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* B */

#if defined(__cplusplus)
extern "C" {
#endif
  #define Sattraj_Satellite_INDEX_JAC_C 2
  int Sattraj_Satellite_functionJacC_column(void* data, threadData_t *threadData);
  int Sattraj_Satellite_initialAnalyticJacobianC(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* C */

#if defined(__cplusplus)
extern "C" {
#endif
  #define Sattraj_Satellite_INDEX_JAC_D 1
  int Sattraj_Satellite_functionJacD_column(void* data, threadData_t *threadData);
  int Sattraj_Satellite_initialAnalyticJacobianD(void* data, threadData_t *threadData);
#if defined(__cplusplus)
}
#endif
/* D */


