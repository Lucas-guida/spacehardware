/* Main Simulation File */
#include "Sattraj.Satellite_model.h"

#define prefixedName_performSimulation Sattraj_Satellite_performSimulation
#define prefixedName_updateContinuousSystem Sattraj_Satellite_updateContinuousSystem
#include <simulation/solver/perform_simulation.c>

#define prefixedName_performQSSSimulation Sattraj_Satellite_performQSSSimulation
#include <simulation/solver/perform_qss_simulation.c>

/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int Sattraj_Satellite_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Satellite_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Satellite_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Satellite_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Sattraj_Satellite_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
 equation index: 24
 type: SIMPLE_ASSIGN
 n = 0.004166666666666667 * N0 + 9.645061728395061e-008 * Ndot2 * time + 1.674489883401921e-012 * Nddot6 * time ^ 2.0
 */
void Sattraj_Satellite_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,24};
  modelica_real tmp0;
  tmp0 = data->localData[0]->timeValue;
  data->localData[0]->realVars[22] /* n variable */ = (0.004166666666666667) * (data->simulationInfo->realParameter[1]) + (9.645061728395061e-008) * ((data->simulationInfo->realParameter[3]) * (data->localData[0]->timeValue)) + (1.674489883401921e-012) * ((data->simulationInfo->realParameter[2]) * ((tmp0 * tmp0)));
  TRACE_POP
}
/*
 equation index: 25
 type: SIMPLE_ASSIGN
 der(M) = n
 */
void Sattraj_Satellite_eqFunction_25(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,25};
  data->localData[0]->realVars[1] /* der(M) STATE_DER */ = data->localData[0]->realVars[22] /* n variable */;
  TRACE_POP
}
void Sattraj_Satellite_eqFunction_26(DATA*,threadData_t*);
void Sattraj_Satellite_eqFunction_27(DATA*,threadData_t*);
/*
 equation index: 31
 indexNonlinear: 1
 type: NONLINEAR
 
 vars: {E}
 eqns: {26, 27}
 */
void Sattraj_Satellite_eqFunction_31(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,31};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 31 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[1].nlsxOld[0] = data->localData[0]->realVars[14] /* E variable */;
  retValue = solve_nonlinear_system(data, threadData, 1);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,31};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 31 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[14] /* E variable */ = data->simulationInfo->nonlinearSystemData[1].nlsx[0];
  TRACE_POP
}
/*
 equation index: 32
 type: SIMPLE_ASSIGN
 $cse3 = tan(0.5 * E)
 */
void Sattraj_Satellite_eqFunction_32(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,32};
  data->localData[0]->realVars[11] /* $cse3 variable */ = tan((0.5) * (data->localData[0]->realVars[14] /* E variable */));
  TRACE_POP
}
/*
 equation index: 33
 type: SIMPLE_ASSIGN
 Mean = mod(M, 360.0, 0)
 */
void Sattraj_Satellite_eqFunction_33(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,33};
  data->localData[0]->realVars[16] /* Mean variable */ = _event_mod_real(data->localData[0]->realVars[0] /* M STATE(1,n) */, 360.0, ((modelica_integer) 0), data, threadData);
  TRACE_POP
}
/*
 equation index: 34
 type: SIMPLE_ASSIGN
 $cse4 = DIVISION($cse3, sqrt(DIVISION(1.0 - ecc, 1.0 + ecc)))
 */
void Sattraj_Satellite_eqFunction_34(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,34};
  modelica_real tmp0;
  tmp0 = DIVISION_SIM(1.0 - data->simulationInfo->realParameter[4],1.0 + data->simulationInfo->realParameter[4],"1.0 + ecc",equationIndexes);
  if(!(tmp0 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(DIVISION(1.0 - ecc, 1.0 + ecc)) was %g should be >= 0", tmp0);
  }
  data->localData[0]->realVars[12] /* $cse4 variable */ = DIVISION_SIM(data->localData[0]->realVars[11] /* $cse3 variable */,sqrt(tmp0),"sqrt(DIVISION(1.0 - ecc, 1.0 + ecc))",equationIndexes);
  TRACE_POP
}
/*
 equation index: 35
 type: SIMPLE_ASSIGN
 $TMP$VAR$35$0ATAN$TAN = atan($cse4)
 */
void Sattraj_Satellite_eqFunction_35(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,35};
  data->localData[0]->realVars[6] /* $TMP$VAR$35$0ATAN$TAN variable */ = atan(data->localData[0]->realVars[12] /* $cse4 variable */);
  TRACE_POP
}
/*
 equation index: 36
 type: SIMPLE_ASSIGN
 $TMP$VAR$35$0PREX$TAN = if initial() then if pre(theta) == 0.0 then 1.0 else 0.5 * pre(theta) else 0.5 * pre(theta)
 */
void Sattraj_Satellite_eqFunction_36(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,36};
  data->localData[0]->realVars[7] /* $TMP$VAR$35$0PREX$TAN variable */ = (initial()?((data->simulationInfo->realVarsPre[26] /* theta variable */ == 0.0)?1.0:(0.5) * (data->simulationInfo->realVarsPre[26] /* theta variable */)):(0.5) * (data->simulationInfo->realVarsPre[26] /* theta variable */));
  TRACE_POP
}
/*
 equation index: 37
 type: SIMPLE_ASSIGN
 theta = 2.0 * $TMP$VAR$35$0ATAN$TAN + 6.283185307179586 * $_round(($TMP$VAR$35$0PREX$TAN - $TMP$VAR$35$0ATAN$TAN) / 3.141592653589793)
 */
void Sattraj_Satellite_eqFunction_37(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,37};
  modelica_real tmp2;
  tmp2 = 3.141592653589793;
  if (tmp2 == 0) {throwStreamPrint(threadData, "Division by zero %s", "($TMP$VAR$35$0PREX$TAN - $TMP$VAR$35$0ATAN$TAN) / 3.141592653589793");}
  data->localData[0]->realVars[26] /* theta variable */ = (2.0) * (data->localData[0]->realVars[6] /* $TMP$VAR$35$0ATAN$TAN variable */) + (6.283185307179586) * (((modelica_integer)round((modelica_real)((data->localData[0]->realVars[7] /* $TMP$VAR$35$0PREX$TAN variable */ - data->localData[0]->realVars[6] /* $TMP$VAR$35$0ATAN$TAN variable */) / tmp2))));
  TRACE_POP
}
/*
 equation index: 38
 type: SIMPLE_ASSIGN
 $cse2 = sin(theta)
 */
void Sattraj_Satellite_eqFunction_38(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,38};
  data->localData[0]->realVars[10] /* $cse2 variable */ = sin(data->localData[0]->realVars[26] /* theta variable */);
  TRACE_POP
}
/*
 equation index: 39
 type: SIMPLE_ASSIGN
 $cse1 = cos(theta)
 */
void Sattraj_Satellite_eqFunction_39(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,39};
  data->localData[0]->realVars[9] /* $cse1 variable */ = cos(data->localData[0]->realVars[26] /* theta variable */);
  TRACE_POP
}
/*
 equation index: 40
 type: SIMPLE_ASSIGN
 a = DIVISION(398600.4418, (-0.0174532925199433 * n) ^ 2.0) ^ 0.3333333333333333
 */
void Sattraj_Satellite_eqFunction_40(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,40};
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_real tmp10;
  tmp3 = (-0.0174532925199433) * (data->localData[0]->realVars[22] /* n variable */);
  tmp4 = DIVISION_SIM(398600.4418,(tmp3 * tmp3),"(-0.0174532925199433 * n) ^ 2.0",equationIndexes);
  tmp5 = 0.3333333333333333;
  if(tmp4 < 0.0 && tmp5 != 0.0)
  {
    tmp7 = modf(tmp5, &tmp8);
    
    if(tmp7 > 0.5)
    {
      tmp7 -= 1.0;
      tmp8 += 1.0;
    }
    else if(tmp7 < -0.5)
    {
      tmp7 += 1.0;
      tmp8 -= 1.0;
    }
    
    if(fabs(tmp7) < 1e-10)
      tmp6 = pow(tmp4, tmp8);
    else
    {
      tmp10 = modf(1.0/tmp5, &tmp9);
      if(tmp10 > 0.5)
      {
        tmp10 -= 1.0;
        tmp9 += 1.0;
      }
      else if(tmp10 < -0.5)
      {
        tmp10 += 1.0;
        tmp9 -= 1.0;
      }
      if(fabs(tmp10) < 1e-10 && ((unsigned long)tmp9 & 1))
      {
        tmp6 = -pow(-tmp4, tmp7)*pow(tmp4, tmp8);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp4, tmp5);
      }
    }
  }
  else
  {
    tmp6 = pow(tmp4, tmp5);
  }
  if(isnan(tmp6) || isinf(tmp6))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp4, tmp5);
  }
  data->localData[0]->realVars[17] /* a variable */ = tmp6;
  TRACE_POP
}
/*
 equation index: 41
 type: SIMPLE_ASSIGN
 r = a * DIVISION(1.0 - ecc ^ 2.0, 1.0 + ecc * $cse1)
 */
void Sattraj_Satellite_eqFunction_41(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,41};
  modelica_real tmp11;
  tmp11 = data->simulationInfo->realParameter[4];
  data->localData[0]->realVars[25] /* r variable */ = (data->localData[0]->realVars[17] /* a variable */) * (DIVISION_SIM(1.0 - ((tmp11 * tmp11)),1.0 + (data->simulationInfo->realParameter[4]) * (data->localData[0]->realVars[9] /* $cse1 variable */),"1.0 + ecc * $cse1",equationIndexes));
  TRACE_POP
}
/*
 equation index: 42
 type: SIMPLE_ASSIGN
 x = r * $cse1
 */
void Sattraj_Satellite_eqFunction_42(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,42};
  data->localData[0]->realVars[28] /* x variable */ = (data->localData[0]->realVars[25] /* r variable */) * (data->localData[0]->realVars[9] /* $cse1 variable */);
  TRACE_POP
}
/*
 equation index: 43
 type: SIMPLE_ASSIGN
 y = r * $cse2
 */
void Sattraj_Satellite_eqFunction_43(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,43};
  data->localData[0]->realVars[29] /* y variable */ = (data->localData[0]->realVars[25] /* r variable */) * (data->localData[0]->realVars[10] /* $cse2 variable */);
  TRACE_POP
}
/*
 equation index: 44
 type: SIMPLE_ASSIGN
 $TMP$VAR$44$0X$ABS = pre(h)
 */
void Sattraj_Satellite_eqFunction_44(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,44};
  data->localData[0]->realVars[8] /* $TMP$VAR$44$0X$ABS variable */ = data->simulationInfo->realVarsPre[21] /* h variable */;
  TRACE_POP
}
/*
 equation index: 45
 type: SIMPLE_ASSIGN
 h = $_signNoNull($TMP$VAR$44$0X$ABS) * abs(-398600.4418 ^ 0.5 * (-r) ^ 0.5 * (1.0 + ecc * $cse1) ^ 0.5)
 */
void Sattraj_Satellite_eqFunction_45(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,45};
  modelica_real tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  tmp12 = -398600.4418;
  if(!(tmp12 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-398600.4418) was %g should be >= 0", tmp12);
  }tmp13 = (-data->localData[0]->realVars[25] /* r variable */);
  if(!(tmp13 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-r) was %g should be >= 0", tmp13);
  }tmp14 = 1.0 + (data->simulationInfo->realParameter[4]) * (data->localData[0]->realVars[9] /* $cse1 variable */);
  if(!(tmp14 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(1.0 + ecc * $cse1) was %g should be >= 0", tmp14);
  }
  data->localData[0]->realVars[21] /* h variable */ = ((data->localData[0]->realVars[8] /* $TMP$VAR$44$0X$ABS variable */ >= 0.0 ? 1.0:-1.0)) * (fabs((sqrt(tmp12)) * ((sqrt(tmp13)) * (sqrt(tmp14)))));
  TRACE_POP
}
/*
 equation index: 46
 type: SIMPLE_ASSIGN
 dr = 398600.4418 * ecc * DIVISION($cse2, h)
 */
void Sattraj_Satellite_eqFunction_46(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,46};
  data->localData[0]->realVars[18] /* dr variable */ = (398600.4418) * ((data->simulationInfo->realParameter[4]) * (DIVISION_SIM(data->localData[0]->realVars[10] /* $cse2 variable */,data->localData[0]->realVars[21] /* h variable */,"h",equationIndexes)));
  TRACE_POP
}
/*
 equation index: 47
 type: SIMPLE_ASSIGN
 dx = -398600.4418 * DIVISION($cse2, h)
 */
void Sattraj_Satellite_eqFunction_47(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,47};
  data->localData[0]->realVars[19] /* dx variable */ = (-398600.4418) * (DIVISION_SIM(data->localData[0]->realVars[10] /* $cse2 variable */,data->localData[0]->realVars[21] /* h variable */,"h",equationIndexes));
  TRACE_POP
}
/*
 equation index: 48
 type: SIMPLE_ASSIGN
 dy = 398600.4418 * DIVISION(ecc + $cse1, h)
 */
void Sattraj_Satellite_eqFunction_48(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,48};
  data->localData[0]->realVars[20] /* dy variable */ = (398600.4418) * (DIVISION_SIM(data->simulationInfo->realParameter[4] + data->localData[0]->realVars[9] /* $cse1 variable */,data->localData[0]->realVars[21] /* h variable */,"h",equationIndexes));
  TRACE_POP
}


int Sattraj_Satellite_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  Sattraj_Satellite_functionLocalKnownVars(data, threadData);
  Sattraj_Satellite_eqFunction_24(data, threadData);

  Sattraj_Satellite_eqFunction_25(data, threadData);

  Sattraj_Satellite_eqFunction_31(data, threadData);

  Sattraj_Satellite_eqFunction_32(data, threadData);

  Sattraj_Satellite_eqFunction_33(data, threadData);

  Sattraj_Satellite_eqFunction_34(data, threadData);

  Sattraj_Satellite_eqFunction_35(data, threadData);

  Sattraj_Satellite_eqFunction_36(data, threadData);

  Sattraj_Satellite_eqFunction_37(data, threadData);

  Sattraj_Satellite_eqFunction_38(data, threadData);

  Sattraj_Satellite_eqFunction_39(data, threadData);

  Sattraj_Satellite_eqFunction_40(data, threadData);

  Sattraj_Satellite_eqFunction_41(data, threadData);

  Sattraj_Satellite_eqFunction_42(data, threadData);

  Sattraj_Satellite_eqFunction_43(data, threadData);

  Sattraj_Satellite_eqFunction_44(data, threadData);

  Sattraj_Satellite_eqFunction_45(data, threadData);

  Sattraj_Satellite_eqFunction_46(data, threadData);

  Sattraj_Satellite_eqFunction_47(data, threadData);

  Sattraj_Satellite_eqFunction_48(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Sattraj_Satellite_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/* forwarded equations */
extern void Sattraj_Satellite_eqFunction_24(DATA* data, threadData_t *threadData);
extern void Sattraj_Satellite_eqFunction_25(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  Sattraj_Satellite_eqFunction_24(data, threadData);

  Sattraj_Satellite_eqFunction_25(data, threadData);
}

int Sattraj_Satellite_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  Sattraj_Satellite_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "Sattraj.Satellite_12jac.h"
#include "Sattraj.Satellite_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks Sattraj_Satellite_callback = {
   (int (*)(DATA *, threadData_t *, void *)) Sattraj_Satellite_performSimulation,
   (int (*)(DATA *, threadData_t *, void *)) Sattraj_Satellite_performQSSSimulation,
   Sattraj_Satellite_updateContinuousSystem,
   Sattraj_Satellite_callExternalObjectDestructors,
   Sattraj_Satellite_initialNonLinearSystem,
   NULL,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   Sattraj_Satellite_initializeStateSets,
   #else
   NULL,
   #endif
   Sattraj_Satellite_initializeDAEmodeData,
   Sattraj_Satellite_functionODE,
   Sattraj_Satellite_functionAlgebraics,
   Sattraj_Satellite_functionDAE,
   Sattraj_Satellite_functionLocalKnownVars,
   Sattraj_Satellite_input_function,
   Sattraj_Satellite_input_function_init,
   Sattraj_Satellite_input_function_updateStartValues,
   Sattraj_Satellite_output_function,
   Sattraj_Satellite_function_storeDelayed,
   Sattraj_Satellite_updateBoundVariableAttributes,
   Sattraj_Satellite_functionInitialEquations,
   0,
   Sattraj_Satellite_functionInitialEquations_lambda0,
   Sattraj_Satellite_functionRemovedInitialEquations,
   Sattraj_Satellite_updateBoundParameters,
   Sattraj_Satellite_checkForAsserts,
   Sattraj_Satellite_function_ZeroCrossingsEquations,
   Sattraj_Satellite_function_ZeroCrossings,
   Sattraj_Satellite_function_updateRelations,
   Sattraj_Satellite_checkForDiscreteChanges,
   Sattraj_Satellite_zeroCrossingDescription,
   Sattraj_Satellite_relationDescription,
   Sattraj_Satellite_function_initSample,
   Sattraj_Satellite_INDEX_JAC_A,
   Sattraj_Satellite_INDEX_JAC_B,
   Sattraj_Satellite_INDEX_JAC_C,
   Sattraj_Satellite_INDEX_JAC_D,
   Sattraj_Satellite_initialAnalyticJacobianA,
   Sattraj_Satellite_initialAnalyticJacobianB,
   Sattraj_Satellite_initialAnalyticJacobianC,
   Sattraj_Satellite_initialAnalyticJacobianD,
   Sattraj_Satellite_functionJacA_column,
   Sattraj_Satellite_functionJacB_column,
   Sattraj_Satellite_functionJacC_column,
   Sattraj_Satellite_functionJacD_column,
   Sattraj_Satellite_linear_model_frame,
   Sattraj_Satellite_linear_model_datarecovery_frame,
   Sattraj_Satellite_mayer,
   Sattraj_Satellite_lagrange,
   Sattraj_Satellite_pickUpBoundsForInputsInOptimization,
   Sattraj_Satellite_setInputData,
   Sattraj_Satellite_getTimeGrid,
   Sattraj_Satellite_symbolicInlineSystem,
   Sattraj_Satellite_function_initSynchronous,
   Sattraj_Satellite_function_updateSynchronous,
   Sattraj_Satellite_function_equationsSynchronous,
   NULL
   #ifdef FMU_EXPERIMENTAL
   ,Sattraj_Satellite_functionODE_Partial
   ,Sattraj_Satellite_functionFMIJacobian
   #endif
   ,Sattraj_Satellite_inputNames


};

void Sattraj_Satellite_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &Sattraj_Satellite_callback;
  data->modelData->modelName = "Sattraj.Satellite";
  data->modelData->modelFilePrefix = "Sattraj.Satellite";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/admin/Desktop/trackingARO-integration/trackingARO-integration";
  data->modelData->modelGUID = "{03d2ff16-5a57-4cf1-9777-bd7d4f674a38}";
  #if defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME)
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  #else
  #if defined(_MSC_VER) /* handle joke compilers */
  {
  /* for MSVC we encode a string like char x[] = {'a', 'b', 'c', '\0'} */
  /* because the string constant limit is 65535 bytes */
  static const char contents_init[] =
    #include "Sattraj.Satellite_init.c"
    ;
  static const char contents_info[] =
    #include "Sattraj.Satellite_info.c"
    ;
    data->modelData->initXMLData = contents_init;
    data->modelData->modelDataXml.infoXMLData = contents_info;
  }
  #else /* handle real compilers */
  data->modelData->initXMLData =
  #include "Sattraj.Satellite_init.c"
    ;
  data->modelData->modelDataXml.infoXMLData =
  #include "Sattraj.Satellite_info.c"
    ;
  #endif /* defined(_MSC_VER) */
  #endif /* defined(OPENMODELICA_XML_FROM_FILE_AT_RUNTIME) */
  
  data->modelData->nStates = 1;
  data->modelData->nVariablesReal = 30;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 6;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 0;
  data->modelData->nOutputVars = 0;
  
  data->modelData->nAliasReal = 4;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 1;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 0;
  data->modelData->nMathEvents = 2;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "Sattraj.Satellite_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 1;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 53;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 2;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 5;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

#if defined(threadData)
#undef threadData
#endif
/* call the simulation runtime main from our main! */
int main(int argc, char**argv)
{
  int res;
  DATA data;
  MODEL_DATA modelData;
  SIMULATION_INFO simInfo;
  data.modelData = &modelData;
  data.simulationInfo = &simInfo;
  measure_time_flag = 0;
  compiledInDAEMode = 0;
  compiledWithSymSolver = 0;
  MMC_INIT(0);
  omc_alloc_interface.init();
  {
    MMC_TRY_TOP()
  
    MMC_TRY_STACK()
  
    Sattraj_Satellite_setupDataStruc(&data, threadData);
    res = _main_SimulationRuntime(argc, argv, &data, threadData);
    
    MMC_ELSE()
    rml_execution_failed();
    fprintf(stderr, "Stack overflow detected and was not caught.\nSend us a bug report at https://trac.openmodelica.org/OpenModelica/newticket\n    Include the following trace:\n");
    printStacktraceMessages();
    fflush(NULL);
    return 1;
    MMC_CATCH_STACK()
    
    MMC_CATCH_TOP(return rml_execution_failed());
  }

  fflush(NULL);
  EXIT(res);
  return res;
}

