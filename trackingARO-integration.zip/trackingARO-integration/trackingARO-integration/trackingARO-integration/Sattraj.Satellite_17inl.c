/* Inline equation file is empty */
#include "Sattraj.Satellite_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int Sattraj_Satellite_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
