/* Events: Sample, Zero Crossings, Relations, Discrete Changes */
#include "Sattraj.Master_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* Initializes the raw time events of the simulation using the now
   calcualted parameters. */
void Sattraj_Master_function_initSample(DATA *data, threadData_t *threadData)
{
  long i=0;
}

const char *Sattraj_Master_zeroCrossingDescription(int i, int **out_EquationIndexes)
{
  static const char *res[] = {"mod(GPS.M, 360.0, 0)"};
  static const int occurEqs0[] = {1,38};
  static const int *occurEqs[] = {occurEqs0};
  *out_EquationIndexes = (int*) occurEqs[i];
  return res[i];
}

/* forwarded equations */
extern void Sattraj_Master_eqFunction_52(DATA* data, threadData_t *threadData);
extern void Sattraj_Master_eqFunction_53(DATA* data, threadData_t *threadData);

int Sattraj_Master_function_ZeroCrossingsEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->callStatistics.functionZeroCrossingsEquations++;

  Sattraj_Master_eqFunction_52(data, threadData);

  Sattraj_Master_eqFunction_53(data, threadData);
  
  TRACE_POP
  return 0;
}

int Sattraj_Master_function_ZeroCrossings(DATA *data, threadData_t *threadData, double *gout)
{
  TRACE_PUSH
  modelica_real tmp0;
  modelica_real tmp1;
  
  data->simulationInfo->callStatistics.functionZeroCrossings++;
  
  tmp0 = floor((data->localData[0]->realVars[0] /* GPS._M STATE(1,GPS.n) */) / (360.0));
  tmp1 = floor((data->simulationInfo->mathEventsValuePre[((modelica_integer) 0)]) / (data->simulationInfo->mathEventsValuePre[((modelica_integer) 0)+1]));
  gout[0] = tmp0 != tmp1 ? 1 : -1;
  
  TRACE_POP
  return 0;
}

const char *Sattraj_Master_relationDescription(int i)
{
  return "empty";
}

int Sattraj_Master_function_updateRelations(DATA *data, threadData_t *threadData, int evalforZeroCross)
{
  TRACE_PUSH
  
  if(evalforZeroCross) {
  } else {
  }
  
  TRACE_POP
  return 0;
}

int Sattraj_Master_checkForDiscreteChanges(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int needToIterate = 0;

  infoStreamPrint(LOG_EVENTS_V, 1, "check for discrete changes at time=%.12g", data->localData[0]->timeValue);
  if (ACTIVE_STREAM(LOG_EVENTS_V)) messageClose(LOG_EVENTS_V);
  
  TRACE_POP
  return needToIterate;
}

#if defined(__cplusplus)
}
#endif

