/* Mixed Systems */
#include "Sattraj.Master_model.h"
#include "Sattraj.Master_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */


