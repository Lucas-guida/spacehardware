/* DAE residuals is empty */
 #include "Sattraj.Master_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int Sattraj_Master_initializeDAEmodeData(DATA *inData, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
