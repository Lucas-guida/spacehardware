#include "Sattraj.Master_functions.h"
#ifdef __cplusplus
extern "C" {
#endif

#include "Sattraj.Master_includes.h"


Sattraj_Vector omc_Sattraj_Vector(threadData_t *threadData, modelica_real omc_x, modelica_real omc_y, modelica_real omc_z)
{
  Sattraj_Vector tmp1;
  tmp1._x = omc_x;
  tmp1._y = omc_y;
  tmp1._z = omc_z;
  return tmp1;
}

modelica_metatype boxptr_Sattraj_Vector(threadData_t *threadData, modelica_metatype _x, modelica_metatype _y, modelica_metatype _z)
{
  return mmc_mk_box4(3, &Sattraj_Vector__desc, _x, _y, _z);
}

DLLExport
Sattraj_Vector omc_Sattraj_range__ECF2topo(threadData_t *threadData, Sattraj_Vector _p_sat_ecf, Sattraj_Vector _v_sat_ecf, Sattraj_Vector _p_stn_ecf, modelica_real _longitude, modelica_real _latitude, Sattraj_Vector *out_v_sat_topo)
{
  Sattraj_Vector _p_sat_topo;
  Sattraj_Vector _v_sat_topo;
  real_array _p;
  real_array _v;
  modelica_real _pi;
  modelica_real _long;
  modelica_real _lat;
  real_array _R;
  real_array tmp1;
  real_array tmp2;
  real_array tmp3;
  real_array tmp4;
  real_array tmp5;
  real_array tmp6;
  real_array tmp7;
  real_array tmp8;
  real_array tmp9;
  _tailrecursive: OMC_LABEL_UNUSED
  alloc_real_array(&_p, 2, ((modelica_integer) 3), ((modelica_integer) 1));
  alloc_real_array(&_v, 2, ((modelica_integer) 3), ((modelica_integer) 1));
  _pi = 3.141592653589793;
  _long = (0.005555555555555556) * ((_longitude) * (_pi));
  _lat = (0.005555555555555556) * ((_latitude) * (_pi));
  /* -- start: matrix[3,3] -- */
  alloc_real_array(&tmp1, 2, 3, 3);
  put_real_matrix_element((-sin(_long)), 0, 0, &tmp1);
  put_real_matrix_element(cos(_long), 0, 1, &tmp1);
  put_real_matrix_element(0.0, 0, 2, &tmp1);
  put_real_matrix_element(((-cos(_long))) * (sin(_lat)), 1, 0, &tmp1);
  put_real_matrix_element(((-sin(_long))) * (cos(_lat)), 1, 1, &tmp1);
  put_real_matrix_element(cos(_lat), 1, 2, &tmp1);
  put_real_matrix_element((cos(_long)) * (cos(_lat)), 2, 0, &tmp1);
  put_real_matrix_element((sin(_long)) * (cos(_lat)), 2, 1, &tmp1);
  put_real_matrix_element(sin(_lat), 2, 2, &tmp1);
  /* -- end: matrix[3,3] -- */
  _R = tmp1;
  array_alloc_scalar_real_array(&tmp3, 1, (modelica_real)((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_ecf._z) - (((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_stn_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_stn_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_stn_ecf._z)));
  array_alloc_scalar_real_array(&tmp4, 1, (modelica_real)((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_ecf._z) - (((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_stn_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_stn_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_stn_ecf._z)));
  array_alloc_scalar_real_array(&tmp5, 1, (modelica_real)((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_ecf._z) - (((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_stn_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_stn_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_stn_ecf._z)));
  array_alloc_real_array(&tmp2, 3, tmp3, tmp4, tmp5);
  copy_real_array_data(tmp2, &_p);

  array_alloc_scalar_real_array(&tmp7, 1, (modelica_real)((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_ecf._z));
  array_alloc_scalar_real_array(&tmp8, 1, (modelica_real)((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_ecf._z));
  array_alloc_scalar_real_array(&tmp9, 1, (modelica_real)((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_ecf._x) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_ecf._y) + ((*real_array_element_addr2(&_R, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_ecf._z));
  array_alloc_real_array(&tmp6, 3, tmp7, tmp8, tmp9);
  copy_real_array_data(tmp6, &_v);

  _p_sat_topo._x = (*real_array_element_addr2(&_p, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)));

  _p_sat_topo._y = (*real_array_element_addr2(&_p, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)));

  _p_sat_topo._z = (*real_array_element_addr2(&_p, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_topo._x = (*real_array_element_addr2(&_v, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_topo._y = (*real_array_element_addr2(&_v, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_topo._z = (*real_array_element_addr2(&_v, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)));
  _return: OMC_LABEL_UNUSED
  if (out_v_sat_topo) { *out_v_sat_topo = _v_sat_topo; }
  return _p_sat_topo;
}
modelica_metatype boxptr_Sattraj_range__ECF2topo(threadData_t *threadData, modelica_metatype _p_sat_ecf, modelica_metatype _v_sat_ecf, modelica_metatype _p_stn_ecf, modelica_metatype _longitude, modelica_metatype _latitude, modelica_metatype *out_v_sat_topo)
{
  Sattraj_Vector tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  Sattraj_Vector tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  Sattraj_Vector tmp9;
  modelica_real tmp10;
  modelica_real tmp11;
  modelica_real tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  Sattraj_Vector _v_sat_topo;
  Sattraj_Vector _p_sat_topo;
  modelica_metatype out_p_sat_topo;
  modelica_metatype tmpMeta[15] __attribute__((unused)) = {0};
  tmpMeta[0] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_ecf), 2)));
  tmp2 = mmc_unbox_real(tmpMeta[0]);
  tmp1._x = tmp2;
  tmpMeta[1] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_ecf), 3)));
  tmp3 = mmc_unbox_real(tmpMeta[1]);
  tmp1._y = tmp3;
  tmpMeta[2] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_ecf), 4)));
  tmp4 = mmc_unbox_real(tmpMeta[2]);
  tmp1._z = tmp4;tmpMeta[3] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_ecf), 2)));
  tmp6 = mmc_unbox_real(tmpMeta[3]);
  tmp5._x = tmp6;
  tmpMeta[4] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_ecf), 3)));
  tmp7 = mmc_unbox_real(tmpMeta[4]);
  tmp5._y = tmp7;
  tmpMeta[5] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_ecf), 4)));
  tmp8 = mmc_unbox_real(tmpMeta[5]);
  tmp5._z = tmp8;tmpMeta[6] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_stn_ecf), 2)));
  tmp10 = mmc_unbox_real(tmpMeta[6]);
  tmp9._x = tmp10;
  tmpMeta[7] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_stn_ecf), 3)));
  tmp11 = mmc_unbox_real(tmpMeta[7]);
  tmp9._y = tmp11;
  tmpMeta[8] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_stn_ecf), 4)));
  tmp12 = mmc_unbox_real(tmpMeta[8]);
  tmp9._z = tmp12;tmp13 = mmc_unbox_real(_longitude);
  tmp14 = mmc_unbox_real(_latitude);
  _p_sat_topo = omc_Sattraj_range__ECF2topo(threadData, tmp1, tmp5, tmp9, tmp13, tmp14, &_v_sat_topo);
  tmpMeta[9] = mmc_mk_rcon(_p_sat_topo._x);
  tmpMeta[10] = mmc_mk_rcon(_p_sat_topo._y);
  tmpMeta[11] = mmc_mk_rcon(_p_sat_topo._z);
  out_p_sat_topo = mmc_mk_box4(3, &Sattraj_Vector__desc, tmpMeta[9], tmpMeta[10], tmpMeta[11]);
  tmpMeta[12] = mmc_mk_rcon(_v_sat_topo._x);
  tmpMeta[13] = mmc_mk_rcon(_v_sat_topo._y);
  tmpMeta[14] = mmc_mk_rcon(_v_sat_topo._z);
  if (out_v_sat_topo) { *out_v_sat_topo = mmc_mk_box4(3, &Sattraj_Vector__desc, tmpMeta[12], tmpMeta[13], tmpMeta[14]); }
  return out_p_sat_topo;
}

DLLExport
modelica_real omc_Sattraj_range__topo2look__angles(threadData_t *threadData, modelica_real _az_vel_lim, modelica_real _el_vel_lim, Sattraj_Vector _p_sat_topo, Sattraj_Vector _v_sat_topo, modelica_real *out_elevation, modelica_real *out_dAz, modelica_real *out_dEl)
{
  modelica_real _azimuth;
  modelica_real _elevation;
  modelica_real _dAz;
  modelica_real _dEl;
  modelica_real _pi;
  real_array _dAzTemp;
  real_array _Rxy;
  real_array tmp1;
  modelica_real _R;
  modelica_real tmp2;
  modelica_real tmp3;
  real_array _vxy;
  real_array tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_real tmp10;
  real_array tmp11;
  modelica_real tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_real tmp15;
  modelica_real tmp16;
  modelica_real tmp17;
  modelica_real tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  _tailrecursive: OMC_LABEL_UNUSED
  _pi = 3.141592653589793;
  alloc_real_array(&_dAzTemp, 1, ((modelica_integer) 3));
  array_alloc_scalar_real_array(&tmp1, 3, (modelica_real)_p_sat_topo._x, (modelica_real)_p_sat_topo._y, (modelica_real)0.0);
  copy_real_array(tmp1, &_Rxy);
  tmp2 = _p_sat_topo._x;
  tmp3 = _p_sat_topo._y;
  _R = sqrt((tmp2 * tmp2) + (tmp3 * tmp3));
  array_alloc_scalar_real_array(&tmp4, 3, (modelica_real)_v_sat_topo._x, (modelica_real)_v_sat_topo._y, (modelica_real)0.0);
  copy_real_array(tmp4, &_vxy);
  tmp5 = _p_sat_topo._y;
  if (tmp5 == 0) {throwStreamPrint(threadData, "Division by zero %s", "p_sat_topo.x / p_sat_topo.y");}
  tmp6 = _pi;
  if (tmp6 == 0) {throwStreamPrint(threadData, "Division by zero %s", "atan(p_sat_topo.x / p_sat_topo.y) / pi");}
  _azimuth = (180.0) * ((atan((_p_sat_topo._x) / tmp5)) / tmp6);

  tmp7 = _p_sat_topo._x;
  tmp8 = _p_sat_topo._y;
  tmp9 = sqrt((tmp7 * tmp7) + (tmp8 * tmp8));
  if (tmp9 == 0) {throwStreamPrint(threadData, "Division by zero %s", "p_sat_topo.z / sqrt(p_sat_topo.x ^ 2.0 + p_sat_topo.y ^ 2.0)");}
  tmp10 = _pi;
  if (tmp10 == 0) {throwStreamPrint(threadData, "Division by zero %s", "atan(p_sat_topo.z / sqrt(p_sat_topo.x ^ 2.0 + p_sat_topo.y ^ 2.0)) / pi");}
  _elevation = (180.0) * ((atan((_p_sat_topo._z) / tmp9)) / tmp10);

  tmp12 = _R;
  tmp13 = (tmp12 * tmp12);
  if (tmp13 == 0) {throwStreamPrint(threadData, "Division by zero %s", "(vxy[2] * Rxy[3] - vxy[3] * Rxy[2]) / R ^ 2.0");}
  tmp14 = _R;
  tmp15 = (tmp14 * tmp14);
  if (tmp15 == 0) {throwStreamPrint(threadData, "Division by zero %s", "(vxy[3] * Rxy[1] - vxy[1] * Rxy[3]) / R ^ 2.0");}
  tmp16 = _R;
  tmp17 = (tmp16 * tmp16);
  if (tmp17 == 0) {throwStreamPrint(threadData, "Division by zero %s", "(vxy[1] * Rxy[2] - vxy[2] * Rxy[1]) / R ^ 2.0");}
  array_alloc_scalar_real_array(&tmp11, 3, (modelica_real)(((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 2)))) * ((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 3)))) - (((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 3)))) * ((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 2)))))) / tmp13, (modelica_real)(((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 3)))) * ((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 1)))) - (((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 1)))) * ((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 3)))))) / tmp15, (modelica_real)(((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 1)))) * ((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 2)))) - (((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 2)))) * ((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 1)))))) / tmp17);
  copy_real_array_data(tmp11, &_dAzTemp);

  _dAz = (*real_array_element_addr1(&_dAzTemp, 1, /* modelica_integer */ ((modelica_integer) 3)));

  tmp18 = _R;
  if (tmp18 == 0) {throwStreamPrint(threadData, "Division by zero %s", "(Rxy[1] * vxy[1] + Rxy[2] * vxy[2]) / R");}
  tmp19 = _R;
  tmp20 = (tmp19 * tmp19);
  if (tmp20 == 0) {throwStreamPrint(threadData, "Division by zero %s", "(R * v_sat_topo.z - p_sat_topo.z * (Rxy[1] * vxy[1] + Rxy[2] * vxy[2]) / R) / R ^ 2.0");}
  _dEl = ((_R) * (_v_sat_topo._z) - ((_p_sat_topo._z) * ((((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 1)))) * ((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 1)))) + ((*real_array_element_addr1(&_Rxy, 1, /* modelica_integer */ ((modelica_integer) 2)))) * ((*real_array_element_addr1(&_vxy, 1, /* modelica_integer */ ((modelica_integer) 2))))) / tmp18))) / tmp20;

  if(((_dAz > _az_vel_lim) || (_dEl > _el_vel_lim)))
  {
    _azimuth = 1e+060;

    _elevation = 1e+060;
  }
  _return: OMC_LABEL_UNUSED
  if (out_elevation) { *out_elevation = _elevation; }
  if (out_dAz) { *out_dAz = _dAz; }
  if (out_dEl) { *out_dEl = _dEl; }
  return _azimuth;
}
modelica_metatype boxptr_Sattraj_range__topo2look__angles(threadData_t *threadData, modelica_metatype _az_vel_lim, modelica_metatype _el_vel_lim, modelica_metatype _p_sat_topo, modelica_metatype _v_sat_topo, modelica_metatype *out_elevation, modelica_metatype *out_dAz, modelica_metatype *out_dEl)
{
  modelica_real tmp1;
  modelica_real tmp2;
  Sattraj_Vector tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  Sattraj_Vector tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_real tmp10;
  modelica_real _elevation;
  modelica_real _dAz;
  modelica_real _dEl;
  modelica_real _azimuth;
  modelica_metatype out_azimuth;
  modelica_metatype tmpMeta[6] __attribute__((unused)) = {0};
  tmp1 = mmc_unbox_real(_az_vel_lim);
  tmp2 = mmc_unbox_real(_el_vel_lim);
  tmpMeta[0] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_topo), 2)));
  tmp4 = mmc_unbox_real(tmpMeta[0]);
  tmp3._x = tmp4;
  tmpMeta[1] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_topo), 3)));
  tmp5 = mmc_unbox_real(tmpMeta[1]);
  tmp3._y = tmp5;
  tmpMeta[2] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_topo), 4)));
  tmp6 = mmc_unbox_real(tmpMeta[2]);
  tmp3._z = tmp6;tmpMeta[3] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_topo), 2)));
  tmp8 = mmc_unbox_real(tmpMeta[3]);
  tmp7._x = tmp8;
  tmpMeta[4] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_topo), 3)));
  tmp9 = mmc_unbox_real(tmpMeta[4]);
  tmp7._y = tmp9;
  tmpMeta[5] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_topo), 4)));
  tmp10 = mmc_unbox_real(tmpMeta[5]);
  tmp7._z = tmp10;
  _azimuth = omc_Sattraj_range__topo2look__angles(threadData, tmp1, tmp2, tmp3, tmp7, &_elevation, &_dAz, &_dEl);
  out_azimuth = mmc_mk_rcon(_azimuth);
  if (out_elevation) { *out_elevation = mmc_mk_rcon(_elevation); }
  if (out_dAz) { *out_dAz = mmc_mk_rcon(_dAz); }
  if (out_dEl) { *out_dEl = mmc_mk_rcon(_dEl); }
  return out_azimuth;
}

DLLExport
Sattraj_Vector omc_Sattraj_sat__ECF(threadData_t *threadData, Sattraj_Vector _p_sat_eci, Sattraj_Vector _v_sat_eci, modelica_real _theta_t, Sattraj_Vector *out_v_sat_ecf)
{
  Sattraj_Vector _p_sat_ecf;
  Sattraj_Vector _v_sat_ecf;
  modelica_real _pi;
  real_array _p;
  real_array _v;
  modelica_real _side_time;
  modelica_real _theta_rad;
  modelica_real _sidereal_rot_rate;
  modelica_real tmp1;
  real_array _R1;
  real_array tmp2;
  real_array _R2;
  real_array tmp3;
  real_array tmp4;
  real_array tmp5;
  real_array tmp6;
  real_array tmp7;
  real_array tmp8;
  real_array tmp9;
  real_array tmp10;
  real_array tmp11;
  _tailrecursive: OMC_LABEL_UNUSED
  _pi = 3.141592653589793;
  alloc_real_array(&_p, 2, ((modelica_integer) 3), ((modelica_integer) 1));
  alloc_real_array(&_v, 2, ((modelica_integer) 3), ((modelica_integer) 1));
  _side_time = 86164.091;
  _theta_rad = (0.005555555555555556) * ((_theta_t) * (_pi));
  tmp1 = _side_time;
  if (tmp1 == 0) {throwStreamPrint(threadData, "Division by zero %s", "pi / side_time");}
  _sidereal_rot_rate = (2.0) * ((_pi) / tmp1);
  /* -- start: matrix[3,3] -- */
  alloc_real_array(&tmp2, 2, 3, 3);
  put_real_matrix_element(cos(_theta_rad), 0, 0, &tmp2);
  put_real_matrix_element(sin(_theta_rad), 0, 1, &tmp2);
  put_real_matrix_element(0.0, 0, 2, &tmp2);
  put_real_matrix_element((-sin(_theta_rad)), 1, 0, &tmp2);
  put_real_matrix_element(cos(_theta_rad), 1, 1, &tmp2);
  put_real_matrix_element(0.0, 1, 2, &tmp2);
  put_real_matrix_element(0.0, 2, 0, &tmp2);
  put_real_matrix_element(0.0, 2, 1, &tmp2);
  put_real_matrix_element(1.0, 2, 2, &tmp2);
  /* -- end: matrix[3,3] -- */
  _R1 = tmp2;
  /* -- start: matrix[3,3] -- */
  alloc_real_array(&tmp3, 2, 3, 3);
  put_real_matrix_element((-sin(_theta_rad)), 0, 0, &tmp3);
  put_real_matrix_element(cos(_theta_rad), 0, 1, &tmp3);
  put_real_matrix_element(0.0, 0, 2, &tmp3);
  put_real_matrix_element((-cos(_theta_rad)), 1, 0, &tmp3);
  put_real_matrix_element((-sin(_theta_rad)), 1, 1, &tmp3);
  put_real_matrix_element(0.0, 1, 2, &tmp3);
  put_real_matrix_element(0.0, 2, 0, &tmp3);
  put_real_matrix_element(0.0, 2, 1, &tmp3);
  put_real_matrix_element(0.0, 2, 2, &tmp3);
  /* -- end: matrix[3,3] -- */
  _R2 = tmp3;
  array_alloc_scalar_real_array(&tmp5, 1, (modelica_real)((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_eci._x) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_eci._y) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_eci._z));
  array_alloc_scalar_real_array(&tmp6, 1, (modelica_real)((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_eci._x) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_eci._y) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_eci._z));
  array_alloc_scalar_real_array(&tmp7, 1, (modelica_real)((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_eci._x) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_eci._y) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_eci._z));
  array_alloc_real_array(&tmp4, 3, tmp5, tmp6, tmp7);
  copy_real_array_data(tmp4, &_p);

  array_alloc_scalar_real_array(&tmp9, 1, (modelica_real)((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_eci._x) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_eci._y) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_eci._z) - ((((-(*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1))))) * (_p_sat_eci._x) - (((*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_eci._y)) - (((*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_eci._z))) * (_sidereal_rot_rate)));
  array_alloc_scalar_real_array(&tmp10, 1, (modelica_real)((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_eci._x) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_eci._y) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_eci._z) - ((((-(*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1))))) * (_p_sat_eci._x) - (((*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_eci._y)) - (((*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_eci._z))) * (_sidereal_rot_rate)));
  array_alloc_scalar_real_array(&tmp11, 1, (modelica_real)((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_eci._x) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_eci._y) + ((*real_array_element_addr2(&_R1, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_eci._z) - ((((-(*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1))))) * (_p_sat_eci._x) - (((*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_eci._y)) - (((*real_array_element_addr2(&_R2, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_eci._z))) * (_sidereal_rot_rate)));
  array_alloc_real_array(&tmp8, 3, tmp9, tmp10, tmp11);
  copy_real_array_data(tmp8, &_v);

  _p_sat_ecf._x = (*real_array_element_addr2(&_p, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)));

  _p_sat_ecf._y = (*real_array_element_addr2(&_p, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)));

  _p_sat_ecf._z = (*real_array_element_addr2(&_p, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_ecf._x = (*real_array_element_addr2(&_v, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_ecf._y = (*real_array_element_addr2(&_v, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_ecf._z = (*real_array_element_addr2(&_v, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)));
  _return: OMC_LABEL_UNUSED
  if (out_v_sat_ecf) { *out_v_sat_ecf = _v_sat_ecf; }
  return _p_sat_ecf;
}
modelica_metatype boxptr_Sattraj_sat__ECF(threadData_t *threadData, modelica_metatype _p_sat_eci, modelica_metatype _v_sat_eci, modelica_metatype _theta_t, modelica_metatype *out_v_sat_ecf)
{
  Sattraj_Vector tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  Sattraj_Vector tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  Sattraj_Vector _v_sat_ecf;
  Sattraj_Vector _p_sat_ecf;
  modelica_metatype out_p_sat_ecf;
  modelica_metatype tmpMeta[12] __attribute__((unused)) = {0};
  tmpMeta[0] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_eci), 2)));
  tmp2 = mmc_unbox_real(tmpMeta[0]);
  tmp1._x = tmp2;
  tmpMeta[1] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_eci), 3)));
  tmp3 = mmc_unbox_real(tmpMeta[1]);
  tmp1._y = tmp3;
  tmpMeta[2] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_eci), 4)));
  tmp4 = mmc_unbox_real(tmpMeta[2]);
  tmp1._z = tmp4;tmpMeta[3] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_eci), 2)));
  tmp6 = mmc_unbox_real(tmpMeta[3]);
  tmp5._x = tmp6;
  tmpMeta[4] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_eci), 3)));
  tmp7 = mmc_unbox_real(tmpMeta[4]);
  tmp5._y = tmp7;
  tmpMeta[5] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_eci), 4)));
  tmp8 = mmc_unbox_real(tmpMeta[5]);
  tmp5._z = tmp8;tmp9 = mmc_unbox_real(_theta_t);
  _p_sat_ecf = omc_Sattraj_sat__ECF(threadData, tmp1, tmp5, tmp9, &_v_sat_ecf);
  tmpMeta[6] = mmc_mk_rcon(_p_sat_ecf._x);
  tmpMeta[7] = mmc_mk_rcon(_p_sat_ecf._y);
  tmpMeta[8] = mmc_mk_rcon(_p_sat_ecf._z);
  out_p_sat_ecf = mmc_mk_box4(3, &Sattraj_Vector__desc, tmpMeta[6], tmpMeta[7], tmpMeta[8]);
  tmpMeta[9] = mmc_mk_rcon(_v_sat_ecf._x);
  tmpMeta[10] = mmc_mk_rcon(_v_sat_ecf._y);
  tmpMeta[11] = mmc_mk_rcon(_v_sat_ecf._z);
  if (out_v_sat_ecf) { *out_v_sat_ecf = mmc_mk_box4(3, &Sattraj_Vector__desc, tmpMeta[9], tmpMeta[10], tmpMeta[11]); }
  return out_p_sat_ecf;
}

DLLExport
Sattraj_Vector omc_Sattraj_sat__ECI(threadData_t *threadData, Sattraj_Vector _p_sat_pf, Sattraj_Vector _v_sat_pf, modelica_real _ecc, modelica_real _raan, modelica_real _inc, modelica_real _argper, modelica_real _N, Sattraj_Vector *out_v_sat_eci)
{
  Sattraj_Vector _p_sat_eci;
  Sattraj_Vector _v_sat_eci;
  modelica_real _pi;
  real_array _pTemp;
  real_array _vTemp;
  modelica_real _w;
  modelica_real _r;
  modelica_real _i;
  real_array _transformation_matrix;
  real_array tmp1;
  real_array tmp2;
  real_array tmp3;
  real_array tmp4;
  real_array tmp5;
  real_array tmp6;
  real_array tmp7;
  real_array tmp8;
  real_array tmp9;
  _tailrecursive: OMC_LABEL_UNUSED
  _pi = 3.141592653589793;
  alloc_real_array(&_pTemp, 2, ((modelica_integer) 3), ((modelica_integer) 1));
  alloc_real_array(&_vTemp, 2, ((modelica_integer) 3), ((modelica_integer) 1));
  _w = (0.005555555555555556) * ((_argper) * (_pi));
  _r = (0.005555555555555556) * ((_raan) * (_pi));
  _i = (0.005555555555555556) * ((_inc) * (_pi));
  /* -- start: matrix[3,3] -- */
  alloc_real_array(&tmp1, 2, 3, 3);
  put_real_matrix_element((cos(_w)) * (cos(_r)) - ((cos(_i)) * ((sin(_w)) * (sin(_r)))), 0, 0, &tmp1);
  put_real_matrix_element(((-sin(_w))) * (cos(_r)) - ((cos(_i)) * ((cos(_w)) * (sin(_r)))), 0, 1, &tmp1);
  put_real_matrix_element((sin(_i)) * (sin(_r)), 0, 2, &tmp1);
  put_real_matrix_element((cos(_i)) * ((cos(_r)) * (sin(_w))) + (cos(_w)) * (sin(_r)), 1, 0, &tmp1);
  put_real_matrix_element((cos(_i)) * ((cos(_w)) * (cos(_r))) - ((sin(_w)) * (sin(_r))), 1, 1, &tmp1);
  put_real_matrix_element(((-sin(_i))) * (cos(_r)), 1, 2, &tmp1);
  put_real_matrix_element((sin(_i)) * (sin(_w)), 2, 0, &tmp1);
  put_real_matrix_element((sin(_i)) * (cos(_w)), 2, 1, &tmp1);
  put_real_matrix_element(cos(_i), 2, 2, &tmp1);
  /* -- end: matrix[3,3] -- */
  _transformation_matrix = tmp1;
  array_alloc_scalar_real_array(&tmp3, 1, (modelica_real)((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_pf._x) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_pf._y) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_pf._z));
  array_alloc_scalar_real_array(&tmp4, 1, (modelica_real)((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_pf._x) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_pf._y) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_pf._z));
  array_alloc_scalar_real_array(&tmp5, 1, (modelica_real)((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)))) * (_p_sat_pf._x) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_p_sat_pf._y) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_p_sat_pf._z));
  array_alloc_real_array(&tmp2, 3, tmp3, tmp4, tmp5);
  copy_real_array_data(tmp2, &_pTemp);

  array_alloc_scalar_real_array(&tmp7, 1, (modelica_real)((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_pf._x) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_pf._y) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_pf._z));
  array_alloc_scalar_real_array(&tmp8, 1, (modelica_real)((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_pf._x) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_pf._y) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_pf._z));
  array_alloc_scalar_real_array(&tmp9, 1, (modelica_real)((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)))) * (_v_sat_pf._x) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 2)))) * (_v_sat_pf._y) + ((*real_array_element_addr2(&_transformation_matrix, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 3)))) * (_v_sat_pf._z));
  array_alloc_real_array(&tmp6, 3, tmp7, tmp8, tmp9);
  copy_real_array_data(tmp6, &_vTemp);

  _p_sat_eci._x = (*real_array_element_addr2(&_pTemp, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)));

  _p_sat_eci._y = (*real_array_element_addr2(&_pTemp, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)));

  _p_sat_eci._z = (*real_array_element_addr2(&_pTemp, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_eci._x = (*real_array_element_addr2(&_vTemp, 2, /* modelica_integer */ ((modelica_integer) 1), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_eci._y = (*real_array_element_addr2(&_vTemp, 2, /* modelica_integer */ ((modelica_integer) 2), /* modelica_integer */ ((modelica_integer) 1)));

  _v_sat_eci._z = (*real_array_element_addr2(&_vTemp, 2, /* modelica_integer */ ((modelica_integer) 3), /* modelica_integer */ ((modelica_integer) 1)));
  _return: OMC_LABEL_UNUSED
  if (out_v_sat_eci) { *out_v_sat_eci = _v_sat_eci; }
  return _p_sat_eci;
}
modelica_metatype boxptr_Sattraj_sat__ECI(threadData_t *threadData, modelica_metatype _p_sat_pf, modelica_metatype _v_sat_pf, modelica_metatype _ecc, modelica_metatype _raan, modelica_metatype _inc, modelica_metatype _argper, modelica_metatype _N, modelica_metatype *out_v_sat_eci)
{
  Sattraj_Vector tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  Sattraj_Vector tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  modelica_real tmp9;
  modelica_real tmp10;
  modelica_real tmp11;
  modelica_real tmp12;
  modelica_real tmp13;
  Sattraj_Vector _v_sat_eci;
  Sattraj_Vector _p_sat_eci;
  modelica_metatype out_p_sat_eci;
  modelica_metatype tmpMeta[12] __attribute__((unused)) = {0};
  tmpMeta[0] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_pf), 2)));
  tmp2 = mmc_unbox_real(tmpMeta[0]);
  tmp1._x = tmp2;
  tmpMeta[1] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_pf), 3)));
  tmp3 = mmc_unbox_real(tmpMeta[1]);
  tmp1._y = tmp3;
  tmpMeta[2] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_p_sat_pf), 4)));
  tmp4 = mmc_unbox_real(tmpMeta[2]);
  tmp1._z = tmp4;tmpMeta[3] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_pf), 2)));
  tmp6 = mmc_unbox_real(tmpMeta[3]);
  tmp5._x = tmp6;
  tmpMeta[4] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_pf), 3)));
  tmp7 = mmc_unbox_real(tmpMeta[4]);
  tmp5._y = tmp7;
  tmpMeta[5] = (MMC_FETCH(MMC_OFFSET(MMC_UNTAGPTR(_v_sat_pf), 4)));
  tmp8 = mmc_unbox_real(tmpMeta[5]);
  tmp5._z = tmp8;tmp9 = mmc_unbox_real(_ecc);
  tmp10 = mmc_unbox_real(_raan);
  tmp11 = mmc_unbox_real(_inc);
  tmp12 = mmc_unbox_real(_argper);
  tmp13 = mmc_unbox_real(_N);
  _p_sat_eci = omc_Sattraj_sat__ECI(threadData, tmp1, tmp5, tmp9, tmp10, tmp11, tmp12, tmp13, &_v_sat_eci);
  tmpMeta[6] = mmc_mk_rcon(_p_sat_eci._x);
  tmpMeta[7] = mmc_mk_rcon(_p_sat_eci._y);
  tmpMeta[8] = mmc_mk_rcon(_p_sat_eci._z);
  out_p_sat_eci = mmc_mk_box4(3, &Sattraj_Vector__desc, tmpMeta[6], tmpMeta[7], tmpMeta[8]);
  tmpMeta[9] = mmc_mk_rcon(_v_sat_eci._x);
  tmpMeta[10] = mmc_mk_rcon(_v_sat_eci._y);
  tmpMeta[11] = mmc_mk_rcon(_v_sat_eci._z);
  if (out_v_sat_eci) { *out_v_sat_eci = mmc_mk_box4(3, &Sattraj_Vector__desc, tmpMeta[9], tmpMeta[10], tmpMeta[11]); }
  return out_p_sat_eci;
}

DLLExport
modelica_real omc_Sattraj_theta__t(threadData_t *threadData, modelica_real _din, modelica_real _tm)
{
  modelica_real _theta_t;
  modelica_real _theta_mid;
  modelica_real _r;
  modelica_real _d;
  modelica_real _T;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  _tailrecursive: OMC_LABEL_UNUSED
  _d = -2451545.0 + _din;
  _T = (2.737850787132101e-005) * (_d);
  tmp1 = _T;
  tmp2 = _T;
  tmp3 = 86400.0;
  if (tmp3 == 0) {throwStreamPrint(threadData, "Division by zero %s", "mod(24110.54841 + 8640184.812866001 * T + 0.09310400000000001 * T ^ 2.0 + -6.2e-006 * T ^ 3.0, 86400.0)");}
  _theta_mid = (0.004166666666666667) * (((24110.54841 + (8640184.812866001) * (_T) + (0.09310400000000001) * ((tmp1 * tmp1)) + (-6.2e-006) * ((tmp2 * tmp2 * tmp2))) - floor((24110.54841 + (8640184.812866001) * (_T) + (0.09310400000000001) * ((tmp1 * tmp1)) + (-6.2e-006) * ((tmp2 * tmp2 * tmp2))) / (tmp3)) * (tmp3)));

  tmp4 = _T;
  _r = 1.002737909350795 + (5.900600000000007e-011) * (_T) + (-5.90000000000001e-015) * ((tmp4 * tmp4));

  tmp5 = 360.0;
  if (tmp5 == 0) {throwStreamPrint(threadData, "Division by zero %s", "mod(theta_mid + 360.0 * r * (din - tm), 360.0)");}
  _theta_t = ((_theta_mid + (360.0) * ((_r) * (_din - _tm))) - floor((_theta_mid + (360.0) * ((_r) * (_din - _tm))) / (tmp5)) * (tmp5));
  _return: OMC_LABEL_UNUSED
  return _theta_t;
}
modelica_metatype boxptr_Sattraj_theta__t(threadData_t *threadData, modelica_metatype _din, modelica_metatype _tm)
{
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real _theta_t;
  modelica_metatype out_theta_t;
  tmp1 = mmc_unbox_real(_din);
  tmp2 = mmc_unbox_real(_tm);
  _theta_t = omc_Sattraj_theta__t(threadData, tmp1, tmp2);
  out_theta_t = mmc_mk_rcon(_theta_t);
  return out_theta_t;
}

#ifdef __cplusplus
}
#endif
