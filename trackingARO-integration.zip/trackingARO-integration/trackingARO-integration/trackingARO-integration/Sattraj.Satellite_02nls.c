/* Non Linear Systems */
#include "Sattraj.Satellite_model.h"
#include "Sattraj.Satellite_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* inner equations */

void residualFunc10(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,10};
  /* iteration variables */
  data->localData[0]->realVars[14] /* E variable */ = xloc[0];
  /* backup outputs */
  /* pre body */
  /* body */
  res[0] = data->localData[0]->realVars[14] /* E variable */ + (data->simulationInfo->realParameter[4]) * (sin(data->localData[0]->realVars[14] /* E variable */)) + (-0.0174532925199433) * (data->localData[0]->realVars[0] /* M STATE(1,n) */);
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS10(NONLINEAR_SYSTEM_DATA* inSysData)
{
  /* no sparsity pattern available */
  inSysData->isPatternAvailable = 0;
}
void initializeStaticDataNLS10(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for E */
  sysData->nominal[i] = data->modelData->realVarsData[14].attribute /* E */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[14].attribute /* E */.min;
  sysData->max[i++]   = data->modelData->realVarsData[14].attribute /* E */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS10(sysData);
}

void getIterationVarsNLS10(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[14] /* E variable */;
}

/* inner equations */

/*
 equation index: 26
 type: SIMPLE_ASSIGN
 $cse5 = sin(E)
 */
void Sattraj_Satellite_eqFunction_26(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,26};
  data->localData[0]->realVars[13] /* $cse5 variable */ = sin(data->localData[0]->realVars[14] /* E variable */);
  TRACE_POP
}

void residualFunc31(void** dataIn, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = (DATA*) ((void**)dataIn[0]);
  threadData_t *threadData = (threadData_t*) ((void**)dataIn[1]);
  const int equationIndexes[2] = {1,31};
  /* iteration variables */
  data->localData[0]->realVars[14] /* E variable */ = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  Sattraj_Satellite_eqFunction_26(data, threadData);
  /* body */
  res[0] = (data->simulationInfo->realParameter[4]) * (data->localData[0]->realVars[13] /* $cse5 variable */) + data->localData[0]->realVars[14] /* E variable */ + (-0.0174532925199433) * (data->localData[0]->realVars[0] /* M STATE(1,n) */);
  /* restore known outputs */
  TRACE_POP
}
void initializeSparsePatternNLS31(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = 'T';
  inSysData->sparsePattern.leadindex = (unsigned int*) malloc((1+1)*sizeof(int));
  inSysData->sparsePattern.index = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.numberOfNoneZeros = 1;
  inSysData->sparsePattern.colorCols = (unsigned int*) malloc(1*sizeof(int));
  inSysData->sparsePattern.maxColors = 1;
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern.leadindex, colPtrIndex, (1+1)*sizeof(int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern.leadindex[i] += inSysData->sparsePattern.leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern.index, rowIndex, 1*sizeof(int));
  
  /* write color array */
  inSysData->sparsePattern.colorCols[0] = 1;
}
void initializeStaticDataNLS31(void *inData, threadData_t *threadData, void *inSystemData)
{
  DATA* data = (DATA*) inData;
  NONLINEAR_SYSTEM_DATA* sysData = (NONLINEAR_SYSTEM_DATA*) inSystemData;
  int i=0;
  /* static nls data for E */
  sysData->nominal[i] = data->modelData->realVarsData[14].attribute /* E */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[14].attribute /* E */.min;
  sysData->max[i++]   = data->modelData->realVarsData[14].attribute /* E */.max;
  /* initial sparse pattern */
  initializeSparsePatternNLS31(sysData);
}

void getIterationVarsNLS31(struct DATA *inData, double *array)
{
  DATA* data = (DATA*) inData;
  array[0] = data->localData[0]->realVars[14] /* E variable */;
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize non-linear systems */
void Sattraj_Satellite_initialNonLinearSystem(int nNonLinearSystems, NONLINEAR_SYSTEM_DATA* nonLinearSystemData)
{
  
  nonLinearSystemData[0].equationIndex = 10;
  nonLinearSystemData[0].size = 1;
  nonLinearSystemData[0].homotopySupport = 0;
  nonLinearSystemData[0].mixedSystem = 0;
  nonLinearSystemData[0].residualFunc = residualFunc10;
  nonLinearSystemData[0].strictTearingFunctionCall = NULL;
  nonLinearSystemData[0].analyticalJacobianColumn = NULL;
  nonLinearSystemData[0].initialAnalyticalJacobian = NULL;
  nonLinearSystemData[0].jacobianIndex = -1;
  nonLinearSystemData[0].initializeStaticNLSData = initializeStaticDataNLS10;
  nonLinearSystemData[0].getIterationVars = getIterationVarsNLS10;
  nonLinearSystemData[0].checkConstraints = NULL;
  
  nonLinearSystemData[1].equationIndex = 31;
  nonLinearSystemData[1].size = 1;
  nonLinearSystemData[1].homotopySupport = 0;
  nonLinearSystemData[1].mixedSystem = 0;
  nonLinearSystemData[1].residualFunc = residualFunc31;
  nonLinearSystemData[1].strictTearingFunctionCall = NULL;
  nonLinearSystemData[1].analyticalJacobianColumn = Sattraj_Satellite_functionJacNLSJac0_column;
  nonLinearSystemData[1].initialAnalyticalJacobian = Sattraj_Satellite_initialAnalyticJacobianNLSJac0;
  nonLinearSystemData[1].jacobianIndex = 0;
  nonLinearSystemData[1].initializeStaticNLSData = initializeStaticDataNLS31;
  nonLinearSystemData[1].getIterationVars = getIterationVarsNLS31;
  nonLinearSystemData[1].checkConstraints = NULL;
}

#if defined(__cplusplus)
}
#endif

