/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "Sattraj.Satellite_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

int Sattraj_Satellite_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  /* min ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating min-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* max ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating max-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* nominal **************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating nominal-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating primary start-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  TRACE_POP
  return 0;
}


/*
 equation index: 49
 type: SIMPLE_ASSIGN
 v_sat_p._z = 0.0
 */
void Sattraj_Satellite_eqFunction_49(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,49};
  data->localData[0]->realVars[27] /* v_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 50
 type: SIMPLE_ASSIGN
 GM = 398600.4418
 */
void Sattraj_Satellite_eqFunction_50(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,50};
  data->localData[0]->realVars[15] /* GM variable */ = 398600.4418;
  TRACE_POP
}

/*
 equation index: 51
 type: SIMPLE_ASSIGN
 p_sat_p._z = 0.0
 */
void Sattraj_Satellite_eqFunction_51(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,51};
  data->localData[0]->realVars[23] /* p_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 52
 type: SIMPLE_ASSIGN
 pi = 3.141592653589793
 */
void Sattraj_Satellite_eqFunction_52(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,52};
  data->localData[0]->realVars[24] /* pi variable */ = 3.141592653589793;
  TRACE_POP
}
int Sattraj_Satellite_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Sattraj_Satellite_eqFunction_49(data, threadData);

  Sattraj_Satellite_eqFunction_50(data, threadData);

  Sattraj_Satellite_eqFunction_51(data, threadData);

  Sattraj_Satellite_eqFunction_52(data, threadData);
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

