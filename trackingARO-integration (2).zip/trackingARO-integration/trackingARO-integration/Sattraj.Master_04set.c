/* Initial State Set */
#include "Sattraj.Master_model.h"
#include "Sattraj.Master_11mix.h"
#include "Sattraj.Master_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void Sattraj_Master_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

