/* Initialization */
#include "Sattraj.Satellite_model.h"
#include "Sattraj.Satellite_11mix.h"
#include "Sattraj.Satellite_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void Sattraj_Satellite_functionInitialEquations_0(DATA *data, threadData_t *threadData);


/*
 equation index: 1
 type: SIMPLE_ASSIGN
 v_sat_p._z = 0.0
 */
void Sattraj_Satellite_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  data->localData[0]->realVars[27] /* v_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 2
 type: SIMPLE_ASSIGN
 GM = 398600.4418
 */
void Sattraj_Satellite_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  data->localData[0]->realVars[15] /* GM variable */ = 398600.4418;
  TRACE_POP
}

/*
 equation index: 3
 type: SIMPLE_ASSIGN
 p_sat_p._z = 0.0
 */
void Sattraj_Satellite_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  data->localData[0]->realVars[23] /* p_sat_p._z variable */ = 0.0;
  TRACE_POP
}

/*
 equation index: 4
 type: SIMPLE_ASSIGN
 pi = 3.141592653589793
 */
void Sattraj_Satellite_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  data->localData[0]->realVars[24] /* pi variable */ = 3.141592653589793;
  TRACE_POP
}

/*
 equation index: 5
 type: SIMPLE_ASSIGN
 n = 0.004166666666666667 * N0 + 9.645061728395061e-008 * Ndot2 * time + 1.674489883401921e-012 * Nddot6 * time ^ 2.0
 */
void Sattraj_Satellite_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  modelica_real tmp0;
  tmp0 = data->localData[0]->timeValue;
  data->localData[0]->realVars[22] /* n variable */ = (0.004166666666666667) * (data->simulationInfo->realParameter[1]) + (9.645061728395061e-008) * ((data->simulationInfo->realParameter[3]) * (data->localData[0]->timeValue)) + (1.674489883401921e-012) * ((data->simulationInfo->realParameter[2]) * ((tmp0 * tmp0)));
  TRACE_POP
}

/*
 equation index: 6
 type: SIMPLE_ASSIGN
 der(M) = n
 */
void Sattraj_Satellite_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  data->localData[0]->realVars[1] /* der(M) STATE_DER */ = data->localData[0]->realVars[22] /* n variable */;
  TRACE_POP
}

/*
 equation index: 7
 type: SIMPLE_ASSIGN
 a = DIVISION(398600.4418, (-0.0174532925199433 * n) ^ 2.0) ^ 0.3333333333333333
 */
void Sattraj_Satellite_eqFunction_7(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,7};
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  modelica_real tmp8;
  tmp1 = (-0.0174532925199433) * (data->localData[0]->realVars[22] /* n variable */);
  tmp2 = DIVISION_SIM(398600.4418,(tmp1 * tmp1),"(-0.0174532925199433 * n) ^ 2.0",equationIndexes);
  tmp3 = 0.3333333333333333;
  if(tmp2 < 0.0 && tmp3 != 0.0)
  {
    tmp5 = modf(tmp3, &tmp6);
    
    if(tmp5 > 0.5)
    {
      tmp5 -= 1.0;
      tmp6 += 1.0;
    }
    else if(tmp5 < -0.5)
    {
      tmp5 += 1.0;
      tmp6 -= 1.0;
    }
    
    if(fabs(tmp5) < 1e-10)
      tmp4 = pow(tmp2, tmp6);
    else
    {
      tmp8 = modf(1.0/tmp3, &tmp7);
      if(tmp8 > 0.5)
      {
        tmp8 -= 1.0;
        tmp7 += 1.0;
      }
      else if(tmp8 < -0.5)
      {
        tmp8 += 1.0;
        tmp7 -= 1.0;
      }
      if(fabs(tmp8) < 1e-10 && ((unsigned long)tmp7 & 1))
      {
        tmp4 = -pow(-tmp2, tmp5)*pow(tmp2, tmp6);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp2, tmp3);
      }
    }
  }
  else
  {
    tmp4 = pow(tmp2, tmp3);
  }
  if(isnan(tmp4) || isinf(tmp4))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp2, tmp3);
  }
  data->localData[0]->realVars[17] /* a variable */ = tmp4;
  TRACE_POP
}

/*
 equation index: 8
 type: SIMPLE_ASSIGN
 M = M0 + 0.004166666666666667 * N0 * tstart + 360.0 * (Ndot2 * (1.157407407407407e-005 * tstart) ^ 2.0 + Nddot6 * (1.157407407407407e-005 * tstart) ^ 3.0)
 */
void Sattraj_Satellite_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  modelica_real tmp9;
  modelica_real tmp10;
  tmp9 = (1.157407407407407e-005) * (data->simulationInfo->realParameter[5]);
  tmp10 = (1.157407407407407e-005) * (data->simulationInfo->realParameter[5]);
  data->localData[0]->realVars[0] /* M STATE(1,n) */ = data->simulationInfo->realParameter[0] + (0.004166666666666667) * ((data->simulationInfo->realParameter[1]) * (data->simulationInfo->realParameter[5])) + (360.0) * ((data->simulationInfo->realParameter[3]) * ((tmp9 * tmp9)) + (data->simulationInfo->realParameter[2]) * ((tmp10 * tmp10 * tmp10)));
  TRACE_POP
}

void Sattraj_Satellite_eqFunction_9(DATA*,threadData_t*);
/*
 equation index: 10
 indexNonlinear: 0
 type: NONLINEAR
 
 vars: {E}
 eqns: {9}
 */
void Sattraj_Satellite_eqFunction_10(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,10};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 10 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[0].nlsxOld[0] = data->localData[0]->realVars[14] /* E variable */;
  retValue = solve_nonlinear_system(data, threadData, 0);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,10};
    throwStreamPrintWithEquationIndexes(threadData, indexes, "Solving non-linear system 10 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  data->localData[0]->realVars[14] /* E variable */ = data->simulationInfo->nonlinearSystemData[0].nlsx[0];
  TRACE_POP
}

/*
 equation index: 11
 type: SIMPLE_ASSIGN
 $TMP$VAR$11$0Y$TAN = DIVISION(tan(0.5 * E), sqrt(DIVISION(1.0 - ecc, 1.0 + ecc)))
 */
void Sattraj_Satellite_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  modelica_real tmp0;
  tmp0 = DIVISION_SIM(1.0 - data->simulationInfo->realParameter[4],1.0 + data->simulationInfo->realParameter[4],"1.0 + ecc",equationIndexes);
  if(!(tmp0 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(DIVISION(1.0 - ecc, 1.0 + ecc)) was %g should be >= 0", tmp0);
  }
  data->localData[0]->realVars[4] /* $TMP$VAR$11$0Y$TAN variable */ = DIVISION_SIM(tan((0.5) * (data->localData[0]->realVars[14] /* E variable */)),sqrt(tmp0),"sqrt(DIVISION(1.0 - ecc, 1.0 + ecc))",equationIndexes);
  TRACE_POP
}

/*
 equation index: 12
 type: SIMPLE_ASSIGN
 $TMP$VAR$11$0ATAN$TAN = atan($TMP$VAR$11$0Y$TAN)
 */
void Sattraj_Satellite_eqFunction_12(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,12};
  data->localData[0]->realVars[2] /* $TMP$VAR$11$0ATAN$TAN variable */ = atan(data->localData[0]->realVars[4] /* $TMP$VAR$11$0Y$TAN variable */);
  TRACE_POP
}

/*
 equation index: 13
 type: SIMPLE_ASSIGN
 $TMP$VAR$11$0PREX$TAN = if initial() then if pre(theta) == 0.0 then 1.0 else 0.5 * pre(theta) else 0.5 * pre(theta)
 */
void Sattraj_Satellite_eqFunction_13(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,13};
  data->localData[0]->realVars[3] /* $TMP$VAR$11$0PREX$TAN variable */ = (initial()?((data->simulationInfo->realVarsPre[26] /* theta variable */ == 0.0)?1.0:(0.5) * (data->simulationInfo->realVarsPre[26] /* theta variable */)):(0.5) * (data->simulationInfo->realVarsPre[26] /* theta variable */));
  TRACE_POP
}

/*
 equation index: 14
 type: SIMPLE_ASSIGN
 theta = 2.0 * $TMP$VAR$11$0ATAN$TAN + 6.283185307179586 * $_round(($TMP$VAR$11$0PREX$TAN - $TMP$VAR$11$0ATAN$TAN) / 3.141592653589793)
 */
void Sattraj_Satellite_eqFunction_14(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,14};
  modelica_real tmp2;
  tmp2 = 3.141592653589793;
  if (tmp2 == 0) {throwStreamPrint(threadData, "Division by zero %s", "($TMP$VAR$11$0PREX$TAN - $TMP$VAR$11$0ATAN$TAN) / 3.141592653589793");}
  data->localData[0]->realVars[26] /* theta variable */ = (2.0) * (data->localData[0]->realVars[2] /* $TMP$VAR$11$0ATAN$TAN variable */) + (6.283185307179586) * (((modelica_integer)round((modelica_real)((data->localData[0]->realVars[3] /* $TMP$VAR$11$0PREX$TAN variable */ - data->localData[0]->realVars[2] /* $TMP$VAR$11$0ATAN$TAN variable */) / tmp2))));
  TRACE_POP
}

/*
 equation index: 15
 type: SIMPLE_ASSIGN
 r = a * DIVISION(1.0 - ecc ^ 2.0, 1.0 + ecc * cos(theta))
 */
void Sattraj_Satellite_eqFunction_15(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,15};
  modelica_real tmp3;
  tmp3 = data->simulationInfo->realParameter[4];
  data->localData[0]->realVars[25] /* r variable */ = (data->localData[0]->realVars[17] /* a variable */) * (DIVISION_SIM(1.0 - ((tmp3 * tmp3)),1.0 + (data->simulationInfo->realParameter[4]) * (cos(data->localData[0]->realVars[26] /* theta variable */)),"1.0 + ecc * cos(theta)",equationIndexes));
  TRACE_POP
}

/*
 equation index: 16
 type: SIMPLE_ASSIGN
 x = r * cos(theta)
 */
void Sattraj_Satellite_eqFunction_16(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,16};
  data->localData[0]->realVars[28] /* x variable */ = (data->localData[0]->realVars[25] /* r variable */) * (cos(data->localData[0]->realVars[26] /* theta variable */));
  TRACE_POP
}

/*
 equation index: 17
 type: SIMPLE_ASSIGN
 y = r * sin(theta)
 */
void Sattraj_Satellite_eqFunction_17(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,17};
  data->localData[0]->realVars[29] /* y variable */ = (data->localData[0]->realVars[25] /* r variable */) * (sin(data->localData[0]->realVars[26] /* theta variable */));
  TRACE_POP
}

/*
 equation index: 18
 type: SIMPLE_ASSIGN
 $TMP$VAR$18$0X$ABS = pre(h)
 */
void Sattraj_Satellite_eqFunction_18(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,18};
  data->localData[0]->realVars[5] /* $TMP$VAR$18$0X$ABS variable */ = data->simulationInfo->realVarsPre[21] /* h variable */;
  TRACE_POP
}

/*
 equation index: 19
 type: SIMPLE_ASSIGN
 h = $_signNoNull($TMP$VAR$18$0X$ABS) * abs(-398600.4418 ^ 0.5 * (-r) ^ 0.5 * (1.0 + ecc * cos(theta)) ^ 0.5)
 */
void Sattraj_Satellite_eqFunction_19(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,19};
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  tmp4 = -398600.4418;
  if(!(tmp4 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-398600.4418) was %g should be >= 0", tmp4);
  }tmp5 = (-data->localData[0]->realVars[25] /* r variable */);
  if(!(tmp5 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(-r) was %g should be >= 0", tmp5);
  }tmp6 = 1.0 + (data->simulationInfo->realParameter[4]) * (cos(data->localData[0]->realVars[26] /* theta variable */));
  if(!(tmp6 >= 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
    throwStreamPrintWithEquationIndexes(threadData, equationIndexes, "Model error: Argument of sqrt(1.0 + ecc * cos(theta)) was %g should be >= 0", tmp6);
  }
  data->localData[0]->realVars[21] /* h variable */ = ((data->localData[0]->realVars[5] /* $TMP$VAR$18$0X$ABS variable */ >= 0.0 ? 1.0:-1.0)) * (fabs((sqrt(tmp4)) * ((sqrt(tmp5)) * (sqrt(tmp6)))));
  TRACE_POP
}

/*
 equation index: 20
 type: SIMPLE_ASSIGN
 dr = 398600.4418 * ecc * DIVISION(sin(theta), h)
 */
void Sattraj_Satellite_eqFunction_20(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,20};
  data->localData[0]->realVars[18] /* dr variable */ = (398600.4418) * ((data->simulationInfo->realParameter[4]) * (DIVISION_SIM(sin(data->localData[0]->realVars[26] /* theta variable */),data->localData[0]->realVars[21] /* h variable */,"h",equationIndexes)));
  TRACE_POP
}

/*
 equation index: 21
 type: SIMPLE_ASSIGN
 dx = -398600.4418 * DIVISION(sin(theta), h)
 */
void Sattraj_Satellite_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  data->localData[0]->realVars[19] /* dx variable */ = (-398600.4418) * (DIVISION_SIM(sin(data->localData[0]->realVars[26] /* theta variable */),data->localData[0]->realVars[21] /* h variable */,"h",equationIndexes));
  TRACE_POP
}

/*
 equation index: 22
 type: SIMPLE_ASSIGN
 dy = 398600.4418 * DIVISION(ecc + cos(theta), h)
 */
void Sattraj_Satellite_eqFunction_22(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,22};
  data->localData[0]->realVars[20] /* dy variable */ = (398600.4418) * (DIVISION_SIM(data->simulationInfo->realParameter[4] + cos(data->localData[0]->realVars[26] /* theta variable */),data->localData[0]->realVars[21] /* h variable */,"h",equationIndexes));
  TRACE_POP
}

/*
 equation index: 23
 type: SIMPLE_ASSIGN
 Mean = mod(M, 360.0)
 */
void Sattraj_Satellite_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,23};
  modelica_real tmp7;
  tmp7 = 360.0;
  if (tmp7 == 0) {throwStreamPrint(threadData, "Division by zero %s", "mod(M, 360.0)");}
  data->localData[0]->realVars[16] /* Mean variable */ = ((data->localData[0]->realVars[0] /* M STATE(1,n) */) - floor((data->localData[0]->realVars[0] /* M STATE(1,n) */) / (tmp7)) * (tmp7));
  TRACE_POP
}
void Sattraj_Satellite_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Sattraj_Satellite_eqFunction_1(data, threadData);
  Sattraj_Satellite_eqFunction_2(data, threadData);
  Sattraj_Satellite_eqFunction_3(data, threadData);
  Sattraj_Satellite_eqFunction_4(data, threadData);
  Sattraj_Satellite_eqFunction_5(data, threadData);
  Sattraj_Satellite_eqFunction_6(data, threadData);
  Sattraj_Satellite_eqFunction_7(data, threadData);
  Sattraj_Satellite_eqFunction_8(data, threadData);
  Sattraj_Satellite_eqFunction_10(data, threadData);
  Sattraj_Satellite_eqFunction_11(data, threadData);
  Sattraj_Satellite_eqFunction_12(data, threadData);
  Sattraj_Satellite_eqFunction_13(data, threadData);
  Sattraj_Satellite_eqFunction_14(data, threadData);
  Sattraj_Satellite_eqFunction_15(data, threadData);
  Sattraj_Satellite_eqFunction_16(data, threadData);
  Sattraj_Satellite_eqFunction_17(data, threadData);
  Sattraj_Satellite_eqFunction_18(data, threadData);
  Sattraj_Satellite_eqFunction_19(data, threadData);
  Sattraj_Satellite_eqFunction_20(data, threadData);
  Sattraj_Satellite_eqFunction_21(data, threadData);
  Sattraj_Satellite_eqFunction_22(data, threadData);
  Sattraj_Satellite_eqFunction_23(data, threadData);
  TRACE_POP
}


int Sattraj_Satellite_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  Sattraj_Satellite_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Sattraj_Satellite_functionInitialEquations_lambda0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
int Sattraj_Satellite_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

